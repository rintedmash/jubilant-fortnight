#!/usr/bin/env bash
# ipa2apk.sh — wrap any iOS .ipa into the ios6run Android shell APK.
#
# Takes the original Guille runtime shell (com.guille.ios6run.flap), swaps its
# embedded game bundle for the IPA's Payload/<App>.app, renames the package id
# and label in the binary manifest, converts the app icon, then zipaligns and
# signs. Same pipeline used to build the Touch & Go / Cut the Rope variants.
#
# Requirements: python3, zipalign, apksigner, keytool (all in Debian/Ubuntu:
#   sudo apt install zipalign apksigner default-jre-headless)
#
# Usage:
#   ./ipa2apk.sh -i Game.ipa -o Game-android.apk [-s shell.apk] [-k keystore] [-p pass] [-a alias]
#
# The keystore is auto-generated on first run. Same keystore+pass = updatable installs.

set -euo pipefail

IPA=""; OUT=""; SHELL_APK="$(cd "$(dirname "$0")" && pwd)/shell/flap-runtime-shell.apk"
KEYSTORE="$HOME/.ios6run-repack.keystore"; STORE_PASS="android"; ALIAS="ios6run"

while getopts "i:o:s:k:p:a:h" opt; do
  case "$opt" in
    i) IPA="$OPTARG" ;; o) OUT="$OPTARG" ;; s) SHELL_APK="$OPTARG" ;;
    k) KEYSTORE="$OPTARG" ;; p) STORE_PASS="$OPTARG" ;; a) ALIAS="$OPTARG" ;;
    h) grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *) echo "bad args" >&2; exit 2 ;;
  esac
done
[ -n "$IPA" ] && [ -n "$OUT" ] || { echo "usage: $0 -i Game.ipa -o Game.apk [-s shell.apk]" >&2; exit 2; }
[ -f "$IPA" ] || { echo "ipa not found: $IPA" >&2; exit 2; }
[ -f "$SHELL_APK" ] || { echo "shell apk not found: $SHELL_APK" >&2; exit 2; }
for tool in python3 zipalign apksigner; do command -v "$tool" >/dev/null || { echo "missing: $tool" >&2; exit 2; }; done

WORK="$(mktemp -d)"; trap 'rm -rf "$WORK"' EXIT
STAGE="$WORK/stage.apk"

python3 - "$IPA" "$SHELL_APK" "$STAGE" "$WORK" <<'PYEOF'
import io, os, struct, sys, zipfile, zlib, plistlib, re

ipa, shell, stage, work = sys.argv[1:5]

# ---------- AXML string-pool rebuilder (package id + label rename) ----------
def patch_axml(data, repl):
    typ, hdrsize, size = struct.unpack_from('<HHI', data, 0)
    assert typ == 3, 'not RES_XML'
    pos = hdrsize
    ct, chs, csize, scount, stylecount, flags, sstart, styles = struct.unpack_from('<HHIIIIII', data, pos)
    assert ct == 1 and stylecount == 0 and not (flags & 0x100)
    offs = struct.unpack_from('<%dI' % scount, data, pos + chs)
    strs = []
    for i in range(scount):
        o = pos + sstart + offs[i]
        ln = struct.unpack_from('<H', data, o)[0]
        strs.append(data[o+2:o+2+ln*2].decode('utf-16-le'))
    strs = [repl.get(s, s) for s in strs]
    blob = bytearray(); newoffs = []
    for s in strs:
        newoffs.append(len(blob))
        blob += struct.pack('<H', len(s)) + s.encode('utf-16-le') + b'\0\0'
        while len(blob) % 4: blob += b'\0'
    strings_start = chs + 4 * scount
    pool = struct.pack('<HHIIIIII', 1, 0x1c, strings_start + len(blob), scount, 0, flags, strings_start, 0)
    pool += struct.pack('<%dI' % scount, *newoffs) + bytes(blob)
    rest = data[pos + csize:]
    return struct.pack('<HHI', 3, 8, 8 + len(pool) + len(rest)) + pool + rest

# ---------- PNG decode (regular + Apple CgBI) ----------
def decode_png(data):
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    pos, idat, cgbi, ihdr = 8, b'', False, None
    while pos < len(data):
        ln = struct.unpack('>I', data[pos:pos+4])[0]; typ = data[pos+4:pos+8]; body = data[pos+8:pos+8+ln]
        if typ == b'IHDR': ihdr = struct.unpack('>IIBBBBB', body[:13])
        elif typ == b'CgBI': cgbi = True
        elif typ == b'IDAT': idat += body
        elif typ == b'IEND': break
        pos += 12 + ln
    w, h, depth, ctype = ihdr[:4]
    assert depth == 8, 'only 8-bit PNGs'
    ch = {0:1, 2:3, 4:2, 6:4}[ctype]
    raw = zlib.decompressobj(-15).decompress(idat) if cgbi else zlib.decompress(idat)
    stride = w * ch
    filt = len(raw) == h * (stride + 1)          # CgBI usually strips filter bytes, not always
    if cgbi:
        assert filt or len(raw) == h * stride, 'unexpected CgBI payload size'
    else:
        assert filt, 'unexpected PNG payload size'
    if filt:
        out = bytearray(h * stride); prev = bytearray(stride)
        for y in range(h):
            f = raw[y*(stride+1)]; line = bytearray(raw[y*(stride+1)+1:(y+1)*(stride+1)])
            for i in range(stride):
                a = line[i-ch] if i >= ch else 0; b = prev[i]; c = prev[i-ch] if i >= ch else 0
                if f == 1: line[i] = (line[i] + a) & 255
                elif f == 2: line[i] = (line[i] + b) & 255
                elif f == 3: line[i] = (line[i] + (a + b)//2) & 255
                elif f == 4:
                    p = a + b - c; pa, pb, pc = abs(p-a), abs(p-b), abs(p-c)
                    pr = a if pa <= pb and pa <= pc else (b if pb <= pc else c)
                    line[i] = (line[i] + pr) & 255
            out[y*stride:(y+1)*stride] = line; prev = line
        raw = bytes(out)
    px = bytearray(raw)
    if ch == 4 and cgbi:                      # BGRA premultiplied → RGBA straight
        for i in range(0, len(px), 4):
            b_, g, r, a = px[i], px[i+1], px[i+2], px[i+3]
            if a:
                px[i]   = min(255, r * 255 // a)
                px[i+1] = min(255, g * 255 // a)
                px[i+2] = min(255, b_ * 255 // a)
            else: px[i] = px[i+1] = px[i+2] = 0
            px[i+3] = a
    elif ch == 3:                              # RGB → RGBA opaque
        q = bytearray(len(px)//3*4)
        for i in range(len(px)//3): q[4*i:4*i+4] = px[3*i:3*i+3] + b'\xff'
        px = q
    elif ch == 1:                              # gray → RGBA
        q = bytearray(len(px)*4)
        for i, v in enumerate(px): q[4*i:4*i+4] = bytes([v, v, v, 255])
        px = q
    return w, h, bytes(px)

def encode_png(w, h, rgba):
    def chunk(typ, body):
        c = struct.pack('>I', len(body)) + typ + body
        return c + struct.pack('>I', zlib.crc32(typ + body) & 0xffffffff)
    raw = b''.join(b'\x00' + rgba[y*w*4:(y+1)*w*4] for y in range(h))
    return (b'\x89PNG\r\n\x1a\n'
            + chunk(b'IHDR', struct.pack('>IIBBBBB', w, h, 8, 6, 0, 0, 0))
            + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b''))

def resize_nearest(w, h, rgba, tw, th):
    out = bytearray(tw * th * 4)
    for y in range(th):
        sy = y * h // th
        for x in range(tw):
            sx = x * w // tw
            out[(y*tw+x)*4:(y*tw+x)*4+4] = rgba[(sy*w+sx)*4:(sy*w+sx)*4+4]
    return tw, th, bytes(out)

# ---------- 1. inspect IPA ----------
zin = zipfile.ZipFile(ipa)
cands = sorted({n.split('/')[1] for n in zin.namelist() if n.startswith('Payload/') and n.split('/')[1].endswith('.app')})
assert cands, 'no .app bundle under Payload/'
bundle = cands[0]
info = plistlib.loads(zin.read('Payload/' + bundle + '/Info.plist'))
exe   = info['CFBundleExecutable']
label = info.get('CFBundleDisplayName') or info.get('CFBundleName') or 'Game'
bid   = info.get('CFBundleIdentifier') or 'game'
slug  = re.sub(r'[^a-z0-9]', '', (bid.split('.')[-1] or 'game').lower()) or 'game'
pkg   = 'com.guille.ios6run.' + slug[:40]
print(f'[ipa2apk] bundle: {bundle}  exe: {exe}')
print(f'[ipa2apk] package: {pkg}   label: {label}')

# ---------- 2. pick + convert icon ----------
root = 'Payload/' + bundle + '/'
names = [n for n in zin.namelist()
         if n.startswith(root) and n.count('/') == root.count('/') and n.lower().endswith('.png')]
score = lambda n: (0 if os.path.basename(n).lower() == 'icon.png' else
                   1 if 'icon' in os.path.basename(n).lower() else
                   2 if 'logo' in os.path.basename(n).lower() or n.endswith('iTunesArtwork') else 3,
                   0 if 100 <= zin.getinfo(n).file_size < 500000 else 1,
                   -zin.getinfo(n).file_size)
cands = [root + 'iTunesArtwork'] + sorted(names, key=score)
best = None
for c in cands:
    if c not in zin.namelist(): continue
    try:
        w, h, px = decode_png(zin.read(c))
    except Exception:
        continue
    best = (w, h, px, c); break
assert best, 'no decodable icon found'
w, h, px = best[0], best[1], best[2]
print(f'[ipa2apk] icon source: {best[3]} ({w}x{h})')
w, h, px = resize_nearest(w, h, px, 192, 192)
icon = encode_png(w, h, px)

# ---------- 3. rebuild APK ----------
base = zipfile.ZipFile(shell)
out = zipfile.ZipFile(stage, 'w', zipfile.ZIP_DEFLATED)
patched = {'manifest': 0, 'icon': 0}
for item in base.infolist():
    n = item.filename
    if n.startswith('META-INF/'):                      continue  # old signatures
    if n.startswith('assets/app/'):                    continue  # old game bundle
    if n == 'AndroidManifest.xml':
        mf = patch_axml(base.read(n), {'com.guille.ios6run.flap': pkg, 'Flappy Bird': label})
        out.writestr(n, mf); patched['manifest'] += 1; continue
    if n == 'res/mipmap-xxxhdpi-v4/ic_launcher.png':
        out.writestr(n, icon); patched['icon'] += 1; continue
    out.writestr(item, base.read(n))
assert patched == {'manifest': 1, 'icon': 1}, f'patch failed: {patched}'
for n in zin.namelist():
    if n.startswith('Payload/' + bundle + '/') and not n.endswith('/'):
        out.writestr('assets/app/' + os.path.basename(bundle) + n[len('Payload/' + bundle):], zin.read(n))
out.close()
print(f'[ipa2apk] staged: {stage} ({len(out.namelist())} entries)')

open(os.path.join(work, 'pkgname'), 'w').write(pkg)
PYEOF

# ---------- 4. align + sign ----------
[ -f "$KEYSTORE" ] || keytool -genkeypair -keystore "$KEYSTORE" -alias "$ALIAS" -keyalg RSA \
  -keysize 2048 -validity 10000 -storepass "$STORE_PASS" -keypass "$STORE_PASS" \
  -dname "CN=ios6run repack, O=local, C=US" >/dev/null 2>&1
zipalign -p -f 4 "$STAGE" "$WORK/aligned.apk"
apksigner sign --ks "$KEYSTORE" --ks-pass "pass:$STORE_PASS" --ks-key-alias "$ALIAS" --out "$OUT" "$WORK/aligned.apk"
apksigner verify "$OUT" >/dev/null && echo "[ipa2apk] signed + verified: $OUT (package $(cat "$WORK/pkgname"))"