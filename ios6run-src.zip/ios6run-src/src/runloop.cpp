// ios6run — reconstructed pseudo-source
// units: runloop.cpp + dispatch.cpp + threads.cpp (+ blocks.cpp)
// (evidence: foundation statics perform_later / o_perform_on_main(obj, sel, obj2, d) /
// q_add_operation / m_remove_object / m_remove_all / m_remove_identical / by_selector /
// by_function / by_block; ALooper_prepare/pollAll/addFd/forThread imports)
//
// The NSRunLoop/GCD facade sits on one ALooper-pumped loop on the runtime thread,
// with a work queue for performSelector-style dispatch.

namespace ios6 {

// Work item shapes (from std::function statics): by_selector (id,SEL) / by_function
// (id, fn) / by_block (Block*) — i.e. performSelector:, performBlock:, GCD-ish calls
// all funnel into the same queue. m_remove_* statics implement cancelation
// (cancelPreviousPerformRequestsWithSelector semantics).
struct Work { void* target; const char* sel; double when; };

void  runloop_prepare();             // ALooper_prepare + input-queue fd attachment
void  perform_later(void* obj, const char* sel, double delay);
void  perform_on_main(void* obj, const char* sel, void* arg, double delay);
void  q_add_operation(void* obj, const char* sel);      // detachAsync
void  q_cancel(void* obj, const char* sel);             // m_remove_*

// Main loop, reconstructed:
//   while (running) {
//     ALooper_pollAll(timeout, …)        // lifecycle events, input queue, sensor queue
//     drain perform-queue (items whose `when` ≤ now)
//     if (display link due) {
//        deliver CADisplayLink tick → guest drawView: (uikit.cpp)
//        guest draws via GLES shim; runtime swaps EGL buffers
//        drain autorelease pool        // pool-per-frame classic iOS behavior
//     }
//   }
// Lifecycle mapping: onPause → applicationDidEnterBackground:,
// onResume → applicationWillEnterForeground:/applicationDidBecomeActive:,
// onDestroy → applicationWillTerminate: then exit.

// Timers/NSTimeInterval come from libsystem clock shims (libsystem.cpp);
// NSThread (threads.cpp) wraps pthreads with detachNewThreadSelector semantics.
// dispatch.cpp: the small GCD subset (main queue, async, after) → same work queue.
// blocks.cpp: Apple Block runtime (memcpy-able literal blocks + _Block_copy) so
// guest code taking blocks (OAL async loads) works unmodified.
}