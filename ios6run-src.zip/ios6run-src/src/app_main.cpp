// ios6run — reconstructed pseudo-source
// unit: app_main.cpp + main.cpp  (evidence: sole export ANativeActivity_onCreate,
// JNI strings getIntent/getStringExtra, symbol c_UIApplicationMain)
//
// Boot chain, as observed:
//   Java Standalone unpacks assets/app/<Bundle>.app to filesDir, starts NativeActivity
//   (process ":game") with Intent extra "app" = bundle path, then finishes itself.
//   Android's NativeActivity loads libios6run.so and calls ANativeActivity_onCreate.
//   The runtime reads the "app" extra itself over JNI, then boots the Mach-O.

#include <android/native_activity.h>
#include <android/looper.h>
#include <android/configuration.h>
#include <android/input.h>
#include <android/sensor.h>
#include <pthread.h>
#include <string>

namespace ios6 {
struct RunState;                 // opaque: bundle path, JNIEnv*, ANativeActivity*, window
RunState* run_create(const char* bundlePath, ANativeActivity* activity);
void      run_exec(RunState*);   // never returns while the game lives
void      on_window(RunState*, ANativeWindow* win);   // uikit::set_display_window
void      on_input_queue(RunState*, AInputQueue*);    // attached to this thread's ALooper
void      on_lifecycle(RunState*, int event);         // onResume/onPause/… → UIApplication notifications
}

// --- JNI bridge (strings recovered in .rodata) -------------------------------
// Java helpers the runtime calls back into:
//   com.guille.ios6run.Keyboard.show(Landroid/app/Activity;Z)V   (soft keyboard)
// com.guille.ios6run.Standalone reads nothing back from us; endGame() kills
// the ":game" process from Java when the launcher relaunches.

static std::string jni_intent_extra_app(ANativeActivity* a) {
    JNIEnv* env = nullptr;
    a->vm->AttachCurrentThread(&env, nullptr);          // placeholder: cached JNIEnv in real code
    jobject intent = env->CallObjectMethod(a->clazz,
        env->GetMethodID(env->GetObjectClass(a->clazz), "getIntent", "()Landroid/content/Intent;"));
    jstring japp = (jstring)env->CallObjectMethod(intent,
        env->GetMethodID(env->GetObjectClass(intent), "getStringExtra",
                         "(Ljava/lang/String;)Ljava/lang/String;"),
        env->NewStringUTF("app"));
    const char* s = env->GetStringUTFChars(japp, nullptr);
    std::string out = s;
    env->ReleaseStringUTFChars(japp, s);
    return out;
}

extern "C" __attribute__((visibility("default")))
void ANativeActivity_onCreate(ANativeActivity* activity, void*, size_t) {
    static ios6::RunState* g_state = nullptr;           // one game process per shell APK
    activity->instance = g_state = ios6::run_create(jni_intent_extra_app(activity).c_str(), activity);

    activity->callbacks->onStart             = [](ANativeActivity* a)   { ios6::on_lifecycle((ios6::RunState*)a->instance, APP_CMD_START); };
    activity->callbacks->onResume            = [](ANativeActivity* a)   { ios6::on_lifecycle((ios6::RunState*)a->instance, APP_CMD_RESUME); };
    activity->callbacks->onPause             = [](ANativeActivity* a)   { ios6::on_lifecycle((ios6::RunState*)a->instance, APP_CMD_PAUSE); };
    activity->callbacks->onStop              = [](ANativeActivity* a)   { ios6::on_lifecycle((ios6::RunState*)a->instance, APP_CMD_STOP); };
    activity->callbacks->onDestroy           = [](ANativeActivity* a)   { ios6::on_lifecycle((ios6::RunState*)a->instance, APP_CMD_DESTROY); };
    activity->callbacks->onNativeWindowCreated  = [](ANativeActivity* a, ANativeWindow* w){ ios6::on_window((ios6::RunState*)a->instance, w); };
    activity->callbacks->onInputQueueCreated = [](ANativeActivity* a, AInputQueue* q)  { ios6::on_input_queue((ios6::RunState*)a->instance, q); };
    activity->callbacks->onConfigurationChanged = [](ANativeActivity* a){ /* AConfiguration_* imports live here */ };

    // runtime main on its own thread; Android UI thread only pumps lifecycle/input
    pthread_t t;
    pthread_create(&t, nullptr, [](void* p) -> void* {
        ios6::run_exec((ios6::RunState*)p);
        return nullptr;
    }, g_state);
    pthread_detach(t);
}

// run_exec(), reconstructed flow:
//   1. ios6::foundation::read_plist(<bundle>/Info.plist)   → CFBundleExecutable, CFBundleIdentifier
//   2. ios6::Loader loader; loader.load(<bundle>/<exe>)    → macho image base (see loader.cpp)
//   3. ios6::objc::register_classes_from(__objc_classlist / __objc_catlist / __objc_nlclslist)
//   4. entry = loader.find_entry()                          (LC_MAIN or LC_UNIXTHREAD)
//   5. call entry(argc=1, argv[0]=exe path, envp=iOS-flavored) — i.e. the game's main(),
//      which calls UIApplicationMain(...) → c_UIApplicationMain (see uikit.cpp)