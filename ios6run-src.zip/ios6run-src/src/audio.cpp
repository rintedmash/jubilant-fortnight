// ios6run — reconstructed pseudo-source
// units: openal.cpp + audio_file.cpp + audio_player.cpp + audio_queue.cpp + audio_unit.cpp
// (evidence: _GLOBAL__sub_I_ units; foundation statics mp_play/mp_init_url/pl_set_rate/
// as_load/as_shared/it_init_asset; string "libaaudio.so"; guests import OpenAL +
// AudioToolbox + AVFoundation and ship .caf/.aif/.wav assets)
//
// Two audio stacks the guests use, both lowered onto AAudio (dlopen'd — hence
// libdl in DT_NEEDED but no SLES symbols in the dynamic symtab):

// 1) OpenAL (the games' actual engine API — OALSimpleAudio/ObjectAL in Flap,
//    plain al* calls in Cut the Rope):
//    alcCreateContext/alcGetProcAddress/alcSuspendContext, alGenSources,
//    alSourcef, alGetSourcei, alDeleteSources … implemented over AAudio streams:
//    a mixing thread pulls AL source voices (gain/pitch/loop) and feeds one
//    AAudio output stream. ALBuffers register PCM decoded from CAF/AIFF/WAV
//    (AudioFileReadPackets path → it_init_asset preload with Block callback,
//    "later" static = deferred init queue).
void  al_init();                 // alcCreateContext equivalent
void  al_sourcef(unsigned src, int param, float v);
int   al_get_sourcei(unsigned src, int param, int* v);
void  al_delete_sources(int n, const unsigned* srcs);

// 2) AVFoundation / AVAudioPlayer (mp_* statics): url-based players over the same
//    AAudio mixer — mp_init_url(obj, sel, url), mp_play(obj, sel), pl_set_rate(obj, sel, rate)
//    (playback-rate support, used by Flap's sfx + Touch&Go's wavs via playUrl:loops:).
//    AVAudioSession (as_load/as_shared) just records the category string and
//    configures AAudio usage; interruption notifications are no-ops.

// AudioSession categories accepted (strings in .rodata):
//   Ambient, SoloAmbient, Playback, Record, PlayAndRecord, AudioProcessing
//   + ports BuiltInSpeaker/Headphones (queried, never actually switched)