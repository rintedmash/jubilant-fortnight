// ios6run — reconstructed pseudo-source
// unit: uikit.cpp  (evidence: ios6::uikit::{install, install_gles, install_coregraphics,
// install_nib, install_storekit, deliver_touches, TouchPhase, TouchPoint, resolve_symbol,
// present_drawn, named_color<I,R,G,B>, sc_main, dev_string<kName/kSystemName/
// kSystemVersion/kUniqueIdentifier>, dev_identifier_for_vendor, ipad_app, img_named,
// ctx_present, set_display_window, display_window_size, c_UIApplicationMain,
// g_display, g_display_link, init_display, sc_display_link, the_event})
//
// install() is the class-registration pass for the whole UIKit/CoreGraphics surface:
// UIColor gets template-instantiated named_color<0,0,0,255>-style singletons,
// UIDevice reports kName="iPhone"/kSystemName="iPhone OS"/kSystemVersion≈"6.x",
// dev_identifier_for_vendor → a stored UUID (pi_unique_string rng in foundation).

namespace ios6 { namespace uikit {

enum TouchPhase { Begin, Move, End, Cancel };

struct TouchPoint { float x, y; int id; double timestamp; };

// Touch routing, reconstructed (state statics observed: last_target, last_location,
// last_count, last_time):
//   1. AInputQueue events → AMotionEvent_getX/Y/PointerCount/Action
//   2. hit-test against the registered UIView tree ( UIWindow → EAGLView in both games)
//   3. build a UITouch/NSSet-shaped event, then call the guest's
//      touchesBegan:withEvent: / touchesMoved / touchesEnded / touchesCancelled
//   Target stickiness between Move/End events is what last_target implements.
void deliver_touches(TouchPhase phase, const TouchPoint* points, unsigned count);

// Frame loop: g_display_link emulates CADisplayLink for the guest.
// drawView: gets called at ~frameInterval (60 fps in Flap) — either from
// eglSwapBuffers pacing on the runtime thread or a timed pthread loop.
extern void* g_display_link;

// c_UIApplicationMain(argc, argv, principalClass, delegateClass):
//   - instantiate UIApplication/UIApplicationDelegate from the guest's classes
//   - call application:didFinishLaunchingWithOptions:
//   - create UIWindow (sc_main → mainScreen bounds), rootViewController from MainWindow.nib
//     (install_nib decodes NIBs — Flap has none at runtime, Touch & Go ships MainWindow.nib)
//   - enter the run loop (runloop.cpp) pumping display link + touches
void* c_UIApplicationMain(int argc, char** argv, void* principal, void* delegate);

// Rendering bridge: guest asks for CAEAGLLayer/EAGLContext (GLES 1.1-era code).
// The runtime creates an EGL context on ANativeWindow (set_display_window),
// resolves guest GL calls through resolve_gles_symbol (see gles_shim.cpp),
// and gl_function caches dlsym'd ES3 entry points.
void set_display_window(void* anative_window);
void display_window_size(unsigned& w, unsigned& h);

// icon/photo/asset cache: UIImage imageNamed: → decode via libpng/png.cpp + libjnigraphics
void* img_named(void* cls, const char* name);
}}