// ios6run — reconstructed pseudo-source
// unit: loader.cpp  (evidence: ios6::(anonymous)::Loader symbol set + macho:: types +
// diagnostic strings: ": too small to be Mach-O", "not a 32-bit little-endian Mach-O",
// "truncated fat header", "fat file has no 32-bit ARM slice", "fat slice runs past end
// of file", armv6/armv7/armv7s, NXGetArchInfoFromCpuType, hw.cputype)
//
// This is the user-space dyld. It does NOT use the Android linker for the guest:
// every undefined symbol in the Mach-O is resolved from the runtime's own tables
// (C shims + the ObjC runtime's class registry), because nothing is exported
// dynamically from libios6run.so.

namespace macho {                    // reconstructed Mach-O types (macho:: namespace exists)
struct mach_header { uint32_t magic, cputype, cpusubtype, filetype, ncmds, sizeofcmds, flags; };
struct segment_command { char name[16]; uint32_t vmaddr, vmsize, fileoff, filesize, maxprot, initprot, nsects, flags; };
struct section { char sectname[16], segname[16]; uint32_t addr, size, offset, align, reloff, nreloc, flags, r1, r2, reserved; };
}

namespace ios6 {
enum class BindKind { pointer, text_prel, data_prel };   // reconstructed opcode families

struct Loader {
    // --- fat handling ------------------------------------------------------
    // kPreference is a static in select_slice; strings show it knows armv6/7/7s.
    // Observed behavior: prefers armv7 (9), accepts armv7s (11) and armv6 (6),
    // rejects anything else ("fat file has no 32-bit ARM slice").
    static const uint32_t kPreference = 9;               // armv7
    const macho::mach_header* select_slice();

    // --- mapping -----------------------------------------------------------
    void scan_sections();            // builds segment/section tables (getsectbynamefromheader)
    void protect();                  // mprotect per segment initprot (r-x __TEXT, rw- __DATA)
    void trap_low_pc_reads();        // guard against reads below the image base

    // --- dyld-info opcodes -------------------------------------------------
    void rebase_at(uint32_t offset, uint8_t type);       // classic rebase: add slide
    void bind_at(uint32_t offset, const char* symbol, int lib_ordinal,
                 uint8_t type, uint8_t flags, int64_t addend, BindKind kind);
    void bind_symbol(uint32_t offset, uint32_t str_offset, BindKind, int64_t addend);
    void bind_table(uint32_t offset, uint32_t count, BindKind);   // indirect symbol table pass
    static void* classic_dyld_func_lookup(const char* name, void** out);  // dyld stub binder
    static void  classic_dyld_nothing();                 // no-op for absent optional dyld APIs

    // --- symbol resolution -------------------------------------------------
    // lib_ordinal resolution: -1/-2 self, >=1 maps to a "framework" the runtime
    // implements (or pretends to). Unknown/optional ones fall back to stubs.
    void* resolve(const char* symbol, int lib_ordinal) const;
    bool  is_optional_framework(int lib_ordinal) const;  // kOptional table
    static bool is_optional_function(const char* symbol);
    void  from_framework(int lib_ordinal, /*std::initializer_list<const char*>*/ void* syms) const;

    void* find_entry();              // LC_MAIN → entryoff; LC_UNIXTHREAD → thread pc
};

// load(), reconstructed:
//   const macho::mach_header* mh = select_slice();
//   scan_sections(); map segments from file; protect();
//   execute rebase ops  (__DATA pointers + slide)
//   execute bind ops    (pointer binds: _OBJC_CLASS_$_*, C funcs → resolve())
//                     (lazy binds: __la_symbol_ptr → resolver stub; first call goes
//                      through classic_dyld_func_lookup/"g_dyld_stub_binder")
//   Optional frameworks: missing symbols bind to classic_dyld_nothing / nil class,
//   which is why weak-linked GameKit/StoreKit/MessageUI no-op gracefully.
//   trap_low_pc_reads(); return find_entry();
}