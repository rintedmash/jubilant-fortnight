// ios6run — reconstructed pseudo-source
// unit: gles.cpp  (evidence: resolve_gles_symbol with statics table/fbo/pvrtc/traced;
// fbo_glGenFramebuffers/glBindFramebuffer/glRenderbufferStorage/glFramebufferTexture2D…
// family suffixed OES; present_drawn statics: matrix_mode, load_identity, vertex_pointer,
// tex_coord_pointer, enable_client_state, tex_envi; nearest_textures; gl_function caches)
//
// Guests of this era code against OpenGL ES 1.1 (fixed function + OES_framebuffer_object).
// Android only ships ES3 in libGLESv3 — so the runtime re-implements the ES1.1 surface
// on ES3, including FBO semantics (fbo_* wrappers) and PVR texture support (pvrtc static).

namespace ios6 { namespace uikit {

void* resolve_gles_symbol(const char* name);
//  - direct ES3 dlsym hit (glTexImage2D, glTexParameteri …) → cached in gl_function
//  - *_OES suffixed FBO calls → fbo_* emulation entry points
//  - fixed-function calls → present_drawn emulation

// --- OES framebuffer emulation (reconstructed behavior) -------------------
// The guest thinks it has GL_FRAMEBUFFER_OES. The shim keeps its own namespace of
// framebuffer/renderbuffer objects and lowers everything onto ES3 objects, with
// format fallbacks (fbo_glRenderbufferStorage tries depth16/depth24/rgba variants).
void      fbo_glGenFramebuffers(int n, unsigned* ids);
void      fbo_glBindFramebuffer(unsigned target, unsigned fb);
unsigned  fbo_glCheckFramebufferStatus(unsigned target);
void      fbo_glRenderbufferStorage(unsigned target, unsigned fmt, int w, int h);
void      fbo_glFramebufferTexture2D(unsigned target, unsigned attach, unsigned texTarget, unsigned tex, int level);

// --- fixed-function emulation (present_drawn) -----------------------------
// Guest pattern (verbatim in Flap/Touch&Go/Cocos2d code):
//   glMatrixMode(GL_PROJECTION); glLoadIdentity(); glOrthof(…);
//   glEnableClientState(GL_VERTEX_ARRAY); glVertexPointer(2, GL_FLOAT, …);
//   glTexCoordPointer(2, GL_FLOAT, …); glDrawArrays(GL_TRIANGLE_STRIP, …);
// The shim records matrix + client arrays and translates each draw to:
//   ES3: upload matrix as uniforms, bind VAO/VBO per client array, set
//   GL_TEXTURE_ENV mode (tex_envi static) as a shader constant, then glDrawArrays.
void present_drawn(unsigned first, int count /*, full client-state snapshot */);

// tracing static ("tracing on") enables a GL-call trace — the runtime ships a
// debug switch that logs every guest GL call.
}}