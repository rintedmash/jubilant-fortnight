// ios6run — reconstructed pseudo-source
// unit: objc.cpp  (evidence: ios6::objc::{objc_object, lookup_for, absorb_missing,
// absorb_unrecognized, ns_alloc, dispose_instance, fatal}; symbol types show objc_object
// is a plain C struct with an isa pointer; method lookups take (objc_object*, char* sel))
//
// The guest binary's Objective-C metadata (__objc_classlist, __objc_catlist,
// __objc_nlclslist, __objc_classrefs, __objc_selrefs) is read by the loader and
// registered into THIS runtime. Classes the game imports (UIApplication, UIView,
// …) resolve to the runtime's own implementations registered under the same names.

namespace ios6 { namespace objc {

struct objc_object {
    void* isa;                       // class or metaclass pointer
    // instance layout follows, defined by the registered class's ivar offsets
};

struct Method { const char* name; const char* types; void* imp; };
struct Class;

struct Class {
    Class*       isa;                // metaclass
    Class*       super;
    const char*  name;
    Method*      methods; unsigned method_count;
    /* ivar offsets table, instance size, protocol list … as in classic ABI */
};

// msgSend fast path, reconstructed:
//   id msgSend(id self, SEL sel, ...) {
//       if (!self) return nil;                       // nil messaging returns 0 — critical
//       IMP imp = lookup_for(self, sel);             // cache → class chain
//       return imp(self, sel, ...);
//   }
// Nil-messaging semantics are what let weakly-shimmed features (GameKit etc.) no-op.

void* lookup_for(objc_object* self, const char* sel, void* cache, size_t n);
//  1. per-class method cache (hash on sel)
//  2. walk class → superclass chain (super refs live in __objc_superrefs)
//  3. fall back to absorb_missing (below) instead of crashing

// Unrecognized-selector policy, reconstructed from statics:
//   bool logged;   bool strict;
// absorb_missing / absorb_unrecognized(obj, sel):
//   - log once ("logged"), and either
//     * return nil/0 quietly ("absorb" — keeps optional features dead but harmless), or
//     * raise NSException under "strict"
//   - matches: calling into an unimplemented shim must not kill the game loop.

objc_object* ns_alloc(objc_object* cls, const char* sel);      // alloc with (optional) zone
void dispose_instance(objc_object* obj);                        // -dealloc chain, "keep" statics
void fatal(const char* msg);                                    // objc-level fatal (cxx_fatal exists too)

// class registration at load time:
//   for cls in __objc_classlist: register(cls)         — normal classes
//   for cls in __objc_nlclslist: register(cls); cls->initialize()   — non-lazy (+initialize on load)
//   for cat in __objc_catlist:  attach(cat)            — categories merged into class method lists
// The game's own classes (dot_AppDelegate/dot_EAGLView for Flap; Texture2D/EAGLView/
// BubblesAppDelegate for Touch & Go) are registered verbatim from its binary —
// no rebuild, no re-signing of guest code ever happens.
}}