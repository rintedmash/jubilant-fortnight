# ios6run API surface (machine-generated from `nm libios6run.so` — 26360 symbols)

Grouped by reconstructed namespace. These are real symbol names, not invented.

## ios6::objc… (177 symbols)
```
ios6::objc::(anonymous namespace)::Runtime::~Runtime()
ios6::objc::(anonymous namespace)::absorb_missing(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::absorb_missing(ios6::objc::objc_object*, char const*)::logged
ios6::objc::(anonymous namespace)::absorb_missing(ios6::objc::objc_object*, char const*)::strict
ios6::objc::(anonymous namespace)::absorb_unrecognized(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::absorb_unrecognized(ios6::objc::objc_object*, char const*)::logged
ios6::objc::(anonymous namespace)::add_method_list(ios6::objc::(anonymous namespace)::ClassInfo*, unsigned int)
ios6::objc::(anonymous namespace)::add_property_list(ios6::objc::(anonymous namespace)::ClassInfo*, unsigned int)
ios6::objc::(anonymous namespace)::add_protocol_list(ios6::objc::(anonymous namespace)::ClassInfo*, unsigned int)
ios6::objc::(anonymous namespace)::bootstrap()
ios6::objc::(anonymous namespace)::c_class_addMethod(ios6::objc::class_t*, char const*, void*, char const*)
ios6::objc::(anonymous namespace)::c_class_conformsToProtocol(ios6::objc::class_t*, ios6::objc::(anonymous namespace)::protocol_t const*)
ios6::objc::(anonymous namespace)::c_class_copyMethodList(ios6::objc::class_t*, unsigned int*)
ios6::objc::(anonymous namespace)::c_class_createInstance(ios6::objc::class_t*, unsigned int)
ios6::objc::(anonymous namespace)::c_class_getClassMethod(ios6::objc::class_t*, char const*)
ios6::objc::(anonymous namespace)::c_class_getInstanceMethod(ios6::objc::class_t*, char const*)
ios6::objc::(anonymous namespace)::c_class_getInstanceSize(ios6::objc::class_t*)
ios6::objc::(anonymous namespace)::c_class_getInstanceVariable(ios6::objc::class_t*, char const*)
ios6::objc::(anonymous namespace)::c_class_getIvarLayout(ios6::objc::class_t*)
ios6::objc::(anonymous namespace)::c_class_getMethodImplementation(ios6::objc::class_t*, char const*)
ios6::objc::(anonymous namespace)::c_class_getName(ios6::objc::class_t*)
ios6::objc::(anonymous namespace)::c_class_getProperty(ios6::objc::class_t*, char const*)
ios6::objc::(anonymous namespace)::c_class_getSuperclass(ios6::objc::class_t*)
ios6::objc::(anonymous namespace)::c_class_isMetaClass(ios6::objc::class_t*)
ios6::objc::(anonymous namespace)::c_class_replaceMethod(ios6::objc::class_t*, char const*, void*, char const*)
ios6::objc::(anonymous namespace)::c_class_respondsToSelector(ios6::objc::class_t*, char const*)
ios6::objc::(anonymous namespace)::c_ivar_getName(ios6::objc::(anonymous namespace)::ivar_t const*)
ios6::objc::(anonymous namespace)::c_ivar_getOffset(ios6::objc::(anonymous namespace)::ivar_t const*)
ios6::objc::(anonymous namespace)::c_ivar_getTypeEncoding(ios6::objc::(anonymous namespace)::ivar_t const*)
ios6::objc::(anonymous namespace)::c_method_exchangeImplementations(ios6::objc::(anonymous namespace)::Method*, ios6::objc::(anonymous namespace)::Method*)
ios6::objc::(anonymous namespace)::c_method_getImplementation(ios6::objc::(anonymous namespace)::Method*)
ios6::objc::(anonymous namespace)::c_method_getName(ios6::objc::(anonymous namespace)::Method*)
ios6::objc::(anonymous namespace)::c_method_getTypeEncoding(ios6::objc::(anonymous namespace)::Method*)
ios6::objc::(anonymous namespace)::c_method_setImplementation(ios6::objc::(anonymous namespace)::Method*, void*)
ios6::objc::(anonymous namespace)::c_objc_autorelease(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_autoreleasePoolPop(unsigned int)
ios6::objc::(anonymous namespace)::c_objc_autoreleasePoolPush()
ios6::objc::(anonymous namespace)::c_objc_copyStruct(void*, void const*, int, bool, bool)
ios6::objc::(anonymous namespace)::c_objc_copyWeak(ios6::objc::objc_object**, ios6::objc::objc_object**)
ios6::objc::(anonymous namespace)::c_objc_destroyWeak(ios6::objc::objc_object**)
ios6::objc::(anonymous namespace)::c_objc_enumerationMutation(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_getAssociatedObject(ios6::objc::objc_object*, void const*)
ios6::objc::(anonymous namespace)::c_objc_getClassList(ios6::objc::class_t**, int)
ios6::objc::(anonymous namespace)::c_objc_getMetaClass(char const*)
ios6::objc::(anonymous namespace)::c_objc_getProperty(ios6::objc::objc_object*, char const*, int, bool)
ios6::objc::(anonymous namespace)::c_objc_initWeak(ios6::objc::objc_object**, ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_loadWeak(ios6::objc::objc_object**)
ios6::objc::(anonymous namespace)::c_objc_loadWeakRetained(ios6::objc::objc_object**)
ios6::objc::(anonymous namespace)::c_objc_lookUpClass(char const*)
ios6::objc::(anonymous namespace)::c_objc_moveWeak(ios6::objc::objc_object**, ios6::objc::objc_object**)
ios6::objc::(anonymous namespace)::c_objc_release(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_removeAssociatedObjects(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_retain(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_retainAutorelease(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_retainBlock(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_setAssociatedObject(ios6::objc::objc_object*, void const*, ios6::objc::objc_object*, unsigned int)
ios6::objc::(anonymous namespace)::c_objc_setProperty(ios6::objc::objc_object*, char const*, int, ios6::objc::objc_object*, bool, signed char)
ios6::objc::(anonymous namespace)::c_objc_setProperty_copy(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*, int)
ios6::objc::(anonymous namespace)::c_objc_setProperty_retain(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*, int)
ios6::objc::(anonymous namespace)::c_objc_storeStrong(ios6::objc::objc_object**, ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_storeWeak(ios6::objc::objc_object**, ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_sync_enter(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_objc_sync_exit(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_object_getClass(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_object_getClassName(ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_object_getIvar(ios6::objc::objc_object*, ios6::objc::(anonymous namespace)::ivar_t const*)
ios6::objc::(anonymous namespace)::c_object_setIvar(ios6::objc::objc_object*, ios6::objc::(anonymous namespace)::ivar_t const*, ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::c_property_getAttributes(ios6::objc::(anonymous namespace)::property_t const*)
ios6::objc::(anonymous namespace)::c_protocol_getMethodDescription(ios6::objc::(anonymous namespace)::MethodDescription*, ios6::objc::(anonymous namespace)::protocol_full_t const*, char const*, bool, bool)
ios6::objc::(anonymous namespace)::c_sel_getName(char const*)
ios6::objc::(anonymous namespace)::c_sel_registerName(char const*)
ios6::objc::(anonymous namespace)::fatal(char const*)
ios6::objc::(anonymous namespace)::find_description(ios6::objc::(anonymous namespace)::protocol_full_t const*, char const*, bool, bool, ios6::objc::(anonymous namespace)::MethodDescription*)
ios6::objc::(anonymous namespace)::find_method(ios6::objc::(anonymous namespace)::ClassInfo*, char const*, ios6::objc::(anonymous namespace)::ClassInfo**)
ios6::objc::(anonymous namespace)::flush_caches()
ios6::objc::(anonymous namespace)::g_empty_cache
ios6::objc::(anonymous namespace)::g_empty_vtable
ios6::objc::(anonymous namespace)::g_zombie_class
ios6::objc::(anonymous namespace)::initialize(ios6::objc::(anonymous namespace)::ClassInfo*)
ios6::objc::(anonymous namespace)::kClassPrefix
ios6::objc::(anonymous namespace)::kMetaclassPrefix
ios6::objc::(anonymous namespace)::lookup_imp(ios6::objc::(anonymous namespace)::ClassInfo*, char const*)
ios6::objc::(anonymous namespace)::ns_alloc(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_alloc(ios6::objc::objc_object*, char const*)::with_zone
ios6::objc::(anonymous namespace)::ns_alloc_with_zone(ios6::objc::objc_object*, char const*, void*)
ios6::objc::(anonymous namespace)::ns_autorelease(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_class(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_class_superclass(ios6::objc::class_t*, char const*)
ios6::objc::(anonymous namespace)::ns_conforms_to_protocol(ios6::objc::objc_object*, char const*, ios6::objc::(anonymous namespace)::protocol_t const*)
ios6::objc::(anonymous namespace)::ns_copy(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_copy_class(ios6::objc::objc_object*, char const*, void*)
ios6::objc::(anonymous namespace)::ns_dealloc(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_does_not_recognize(ios6::objc::objc_object*, char const*, char const*)
ios6::objc::(anonymous namespace)::ns_hash(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_instance_method_for_selector(ios6::objc::class_t*, char const*, char const*)
ios6::objc::(anonymous namespace)::ns_instances_respond_to_selector(ios6::objc::class_t*, char const*, char const*)
ios6::objc::(anonymous namespace)::ns_is_equal(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::objc::(anonymous namespace)::ns_is_kind_of_class(ios6::objc::objc_object*, char const*, ios6::objc::class_t*)
ios6::objc::(anonymous namespace)::ns_is_member_of_class(ios6::objc::objc_object*, char const*, ios6::objc::class_t*)
ios6::objc::(anonymous namespace)::ns_is_subclass_of_class(ios6::objc::class_t*, char const*, ios6::objc::class_t*)
ios6::objc::(anonymous namespace)::ns_method_for_selector(ios6::objc::objc_object*, char const*, char const*)
ios6::objc::(anonymous namespace)::ns_mutable_copy(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_new(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_no(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_noop(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_perform0(ios6::objc::objc_object*, char const*, char const*)
ios6::objc::(anonymous namespace)::ns_perform1(ios6::objc::objc_object*, char const*, char const*, unsigned int)
ios6::objc::(anonymous namespace)::ns_perform2(ios6::objc::objc_object*, char const*, char const*, unsigned int, unsigned int)
ios6::objc::(anonymous namespace)::ns_release(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_responds_to_selector(ios6::objc::objc_object*, char const*, char const*)
ios6::objc::(anonymous namespace)::ns_retain(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_retain_count(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_self(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_superclass(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::ns_zone(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::protocol_list_has(unsigned int, char const*)
ios6::objc::(anonymous namespace)::realize(ios6::objc::class_t*)
ios6::objc::(anonymous namespace)::report_unrecognized(ios6::objc::objc_object*, char const*)
ios6::objc::(anonymous namespace)::rt()::r
ios6::objc::(anonymous namespace)::set_property(ios6::objc::objc_object*, int, ios6::objc::objc_object*, int)
ios6::objc::(anonymous namespace)::symbol_table()::table
ios6::objc::(anonymous namespace)::sync_locks()::locks
ios6::objc::(anonymous namespace)::zombies()::z
ios6::objc::add_class_method(ios6::objc::class_t*, char const*, void*, char const*)
ios6::objc::add_method(ios6::objc::class_t*, char const*, void*, char const*)
ios6::objc::autorelease(ios6::objc::objc_object*)
ios6::objc::class_name(ios6::objc::objc_object*)
ios6::objc::clear_side_tables(ios6::objc::objc_object*)
ios6::objc::create_instance(ios6::objc::class_t*, unsigned int)
ios6::objc::define_class(char const*, ios6::objc::class_t*, unsigned int)
ios6::objc::dispose_instance(ios6::objc::objc_object*)
ios6::objc::dispose_instance(ios6::objc::objc_object*)::keep
ios6::objc::forget_weak_slot(ios6::objc::objc_object**)
ios6::objc::g_associated
ios6::objc::g_side_mutex
ios6::objc::g_weak_slots
ios6::objc::is_kind_of(ios6::objc::objc_object*, ios6::objc::class_t*)
ios6::objc::is_runtime_object(ios6::objc::objc_object*)
ios6::objc::is_stub(void const*)
ios6::objc::ivar_offset(ios6::objc::class_t*, char const*)
ios6::objc::ivar_type(ios6::objc::class_t*, char const*)
ios6::objc::lookup_class(char const*)
ios6::objc::make_immortal(ios6::objc::objc_object*)
ios6::objc::make_inert(void const*)
ios6::objc::method_imp(ios6::objc::objc_object*, char const*, bool)
ios6::objc::method_types(ios6::objc::objc_object*, char const*)
ios6::objc::nsobject()
ios6::objc::objc_object* ios6::foundation::(anonymous namespace)::standard<bool (*)(unsigned int)>(ios6::objc::objc_object*, int, bool (*)(unsigned int))
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::dev_string<&ios6::uikit::(anonymous namespace)::kName>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::dev_string<&ios6::uikit::(anonymous namespace)::kSystemName>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::dev_string<&ios6::uikit::(anonymous namespace)::kSystemVersion>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::dev_string<&ios6::uikit::(anonymous namespace)::kUniqueIdentifier>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<0, 0, 0, 0>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<0, 0, 0, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<0, 0, 255, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<0, 255, 0, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<128, 128, 128, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<170, 170, 170, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<197, 204, 212, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<255, 0, 0, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<255, 128, 0, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<255, 255, 0, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<255, 255, 255, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::named_color<85, 85, 85, 255>(ios6::objc::objc_object*, char const*)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::uf_system<false>(ios6::objc::objc_object*, char const*, float)
ios6::objc::objc_object* ios6::uikit::(anonymous namespace)::uf_system<true>(ios6::objc::objc_object*, char const*, float)
ios6::objc::pool_pop(unsigned int)
ios6::objc::pool_push()
ios6::objc::register_image(ios6::Image const&)
ios6::objc::register_image(ios6::Image const&)::$_0::operator()(unsigned int) const
ios6::objc::release(ios6::objc::objc_object*)
ios6::objc::resolve_symbol(char const*, bool)
ios6::objc::retain(ios6::objc::objc_object*)
ios6::objc::sel(char const*)
ios6::objc::send(ios6::objc::objc_object*, char const*, std::initializer_list<unsigned int>)
ios6::objc::send(ios6::objc::objc_object*, char const*, unsigned int, unsigned int)
ios6::objc::send_wide(ios6::objc::objc_object*, char const*, unsigned int, unsigned int)
```

## ios6::foundation… (1331 symbols)
```
ios6::foundation::(anonymous namespace)::B(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::Binary::length(unsigned int&, unsigned char) const
ios6::foundation::(anonymous namespace)::Binary::object(unsigned long long)
ios6::foundation::(anonymous namespace)::CFAbsoluteTimeGetCurrent()
ios6::foundation::(anonymous namespace)::CFArrayAppendValue(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFArrayContainsValue(ios6::objc::objc_object*, ios6::foundation::(anonymous namespace)::CFRange, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFArrayCreate(void*, ios6::objc::objc_object* const*, int, ios6::foundation::(anonymous namespace)::CFArrayCallBacks const*)
ios6::foundation::(anonymous namespace)::CFArrayCreateCopy(void*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFArrayCreateMutable(void*, int, ios6::foundation::(anonymous namespace)::CFArrayCallBacks const*)
ios6::foundation::(anonymous namespace)::CFArrayCreateMutableCopy(void*, int, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFArrayGetCount(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFArrayGetFirstIndexOfValue(ios6::objc::objc_object*, ios6::foundation::(anonymous namespace)::CFRange, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFArrayGetValueAtIndex(ios6::objc::objc_object*, int)
ios6::foundation::(anonymous namespace)::CFArrayInsertValueAtIndex(ios6::objc::objc_object*, int, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFArrayRemoveAllValues(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFArrayRemoveValueAtIndex(ios6::objc::objc_object*, int)
ios6::foundation::(anonymous namespace)::CFArraySetValueAtIndex(ios6::objc::objc_object*, int, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFBooleanGetValue(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFBundleGetBundleWithIdentifier(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFBundleGetIdentifier(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFBundleGetInfoDictionary(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFBundleGetMainBundle()
ios6::foundation::(anonymous namespace)::CFBundleGetValueForInfoDictionaryKey(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFCopyDescription(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDataAppendBytes(ios6::objc::objc_object*, void const*, int)
ios6::foundation::(anonymous namespace)::CFDataCreate(void*, void const*, int)
ios6::foundation::(anonymous namespace)::CFDataCreateMutable(void*, int)
ios6::foundation::(anonymous namespace)::CFDataGetBytePtr(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDataGetBytes(ios6::objc::objc_object*, int, int, void*)
ios6::foundation::(anonymous namespace)::CFDataGetLength(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDataGetMutableBytePtr(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDataSetLength(ios6::objc::objc_object*, int)
ios6::foundation::(anonymous namespace)::CFDictionaryAddValue(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDictionaryApplyFunction(ios6::objc::objc_object*, unsigned int, unsigned int)
ios6::foundation::(anonymous namespace)::CFDictionaryContainsKey(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDictionaryCreate(void*, ios6::objc::objc_object* const*, ios6::objc::objc_object* const*, int, ios6::foundation::(anonymous namespace)::CFDictionaryKeyCallBacks const*, ios6::foundation::(anonymous namespace)::CFDictionaryValueCallBacks const*)
ios6::foundation::(anonymous namespace)::CFDictionaryCreateMutable(void*, int, ios6::foundation::(anonymous namespace)::CFDictionaryKeyCallBacks const*, ios6::foundation::(anonymous namespace)::CFDictionaryValueCallBacks const*)
ios6::foundation::(anonymous namespace)::CFDictionaryCreateMutableCopy(void*, int, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDictionaryGetCount(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDictionaryGetKeysAndValues(ios6::objc::objc_object*, ios6::objc::objc_object**, ios6::objc::objc_object**)
ios6::foundation::(anonymous namespace)::CFDictionaryGetValue(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDictionaryGetValueIfPresent(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object**)
ios6::foundation::(anonymous namespace)::CFDictionaryRemoveAllValues(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDictionaryRemoveValue(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFDictionarySetValue(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFEqual(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFGetRetainCount(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFHash(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFNotificationCenterAddObserver(ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned int, ios6::objc::objc_object*, ios6::objc::objc_object*, int)
ios6::foundation::(anonymous namespace)::CFNotificationCenterGetLocalCenter()
ios6::foundation::(anonymous namespace)::CFNotificationCenterPostNotification(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*, bool)
ios6::foundation::(anonymous namespace)::CFNotificationCenterRemoveEveryObserver(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFNotificationCenterRemoveObserver(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFNumberCreate(void*, int, void const*)
ios6::foundation::(anonymous namespace)::CFNumberGetType(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFNumberGetValue(ios6::objc::objc_object*, int, void*)
ios6::foundation::(anonymous namespace)::CFNumberIsFloatType(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFRelease(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFRetain(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringAppend(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringAppendCString(ios6::objc::objc_object*, char const*, unsigned int)
ios6::foundation::(anonymous namespace)::CFStringAppendFormat(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*, ...)
ios6::foundation::(anonymous namespace)::CFStringCompare(ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned int)
ios6::foundation::(anonymous namespace)::CFStringConvertEncodingToIANACharSetName(unsigned int)
ios6::foundation::(anonymous namespace)::CFStringConvertEncodingToNSStringEncoding(unsigned int)
ios6::foundation::(anonymous namespace)::CFStringConvertIANACharSetNameToEncoding(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringConvertNSStringEncodingToEncoding(unsigned int)
ios6::foundation::(anonymous namespace)::CFStringCreateArrayBySeparatingStrings(void*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringCreateCopy(void*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringCreateMutable(void*, int)
ios6::foundation::(anonymous namespace)::CFStringCreateMutableCopy(void*, int, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringCreateWithBytes(void*, unsigned char const*, int, unsigned int, bool)
ios6::foundation::(anonymous namespace)::CFStringCreateWithCString(void*, char const*, unsigned int)
ios6::foundation::(anonymous namespace)::CFStringCreateWithCharacters(void*, char16_t const*, int)
ios6::foundation::(anonymous namespace)::CFStringCreateWithFormat(void*, ios6::objc::objc_object*, ios6::objc::objc_object*, ...)
ios6::foundation::(anonymous namespace)::CFStringCreateWithFormatAndArguments(void*, ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned int const*)
ios6::foundation::(anonymous namespace)::CFStringCreateWithSubstring(void*, ios6::objc::objc_object*, ios6::foundation::(anonymous namespace)::CFRange)
ios6::foundation::(anonymous namespace)::CFStringFind(ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned int)
ios6::foundation::(anonymous namespace)::CFStringGetCString(ios6::objc::objc_object*, char*, int, unsigned int)
ios6::foundation::(anonymous namespace)::CFStringGetCStringPtr(ios6::objc::objc_object*, unsigned int)
ios6::foundation::(anonymous namespace)::CFStringGetCharacterAtIndex(ios6::objc::objc_object*, unsigned int)
ios6::foundation::(anonymous namespace)::CFStringGetCharactersPtr(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringGetDoubleValue(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringGetFastestEncoding(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringGetIntValue(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringGetLength(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringGetMaximumSizeForEncoding(int, unsigned int)
ios6::foundation::(anonymous namespace)::CFStringHasPrefix(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringHasSuffix(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringLowercase(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFStringTransform(ios6::objc::objc_object*, ios6::foundation::(anonymous namespace)::CFRange*, ios6::objc::objc_object*, bool)
ios6::foundation::(anonymous namespace)::CFStringUppercase(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFURLCopyAbsoluteURL(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFURLCopyFileSystemPath(ios6::objc::objc_object*, int)
ios6::foundation::(anonymous namespace)::CFURLCopyLastPathComponent(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFURLCopyPathExtension(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFURLCreateCopyAppendingPathComponent(void*, ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned char)
ios6::foundation::(anonymous namespace)::CFURLCreateCopyDeletingLastPathComponent(void*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFURLCreateFromFileSystemRepresentation(void*, char const*, int, unsigned char)
ios6::foundation::(anonymous namespace)::CFURLCreateStringByAddingPercentEscapes(void*, ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned int)
ios6::foundation::(anonymous namespace)::CFURLCreateStringByReplacingPercentEscapes(void*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFURLCreateStringByReplacingPercentEscapesUsingEncoding(void*, ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned int)
ios6::foundation::(anonymous namespace)::CFURLCreateWithFileSystemPath(void*, ios6::objc::objc_object*, int, unsigned char)
ios6::foundation::(anonymous namespace)::CFURLCreateWithString(void*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFURLGetFileSystemRepresentation(ios6::objc::objc_object*, unsigned char, char*, int)
ios6::foundation::(anonymous namespace)::CFURLGetString(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFUUIDCreate(void*)
ios6::foundation::(anonymous namespace)::CFUUIDCreateString(void*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::CFUUIDGetUUIDBytes(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::D(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::HashStore::clear()
ios6::foundation::(anonymous namespace)::HashStore::find(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::HashStore::remove(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::HashStore::set(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::NSAllocateObject(ios6::objc::class_t*, unsigned int, void*)
ios6::foundation::(anonymous namespace)::NSClassFromString(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::NSDeallocateObject(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::NSHomeDirectory()
ios6::foundation::(anonymous namespace)::NSLog(ios6::objc::objc_object*, ...)
ios6::foundation::(anonymous namespace)::NSLogv(ios6::objc::objc_object*, unsigned int const*)
ios6::foundation::(anonymous namespace)::NSSearchPathForDirectoriesInDomains(unsigned int, unsigned int, bool)
ios6::foundation::(anonymous namespace)::NSSelectorFromString(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::NSStringFromClass(ios6::objc::class_t*)
ios6::foundation::(anonymous namespace)::NSStringFromProtocol(unsigned int const*)
ios6::foundation::(anonymous namespace)::NSStringFromSelector(char const*)
ios6::foundation::(anonymous namespace)::NSTemporaryDirectory()
ios6::foundation::(anonymous namespace)::NumberState::~NumberState()
ios6::foundation::(anonymous namespace)::Parts::~Parts()
ios6::foundation::(anonymous namespace)::Run::characters(std::__ndk1::basic_string<char, std::__ndk1::char_traits<char>, std::__ndk1::allocator<char> > const&)
ios6::foundation::(anonymous namespace)::Run::fail(unsigned int, std::__ndk1::basic_string<char, std::__ndk1::char_traits<char>, std::__ndk1::allocator<char> > const&)
ios6::foundation::(anonymous namespace)::V(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::Xml::next_tag(ios6::foundation::(anonymous namespace)::Xml::Tag&)
ios6::foundation::(anonymous namespace)::Xml::text(std::__ndk1::basic_string<char, std::__ndk1::char_traits<char>, std::__ndk1::allocator<char> > const&)
ios6::foundation::(anonymous namespace)::Xml::value(ios6::foundation::(anonymous namespace)::Xml::Tag const&)
ios6::foundation::(anonymous namespace)::a_adding_object(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_adding_objects(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_alloc(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_alloc_zone(ios6::objc::objc_object*, char const*, void*)
ios6::foundation::(anonymous namespace)::a_array(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_contains(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_copy(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_count(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_dealloc(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_description(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_enumerate_block(ios6::objc::objc_object*, char const*, ios6::Block*)
ios6::foundation::(anonymous namespace)::a_enumerate_opts_block(ios6::objc::objc_object*, char const*, unsigned int, ios6::Block*)
ios6::foundation::(anonymous namespace)::a_fast_enumerate(ios6::objc::objc_object*, char const*, ios6::foundation::(anonymous namespace)::FastEnumState*, ios6::objc::objc_object**, unsigned int)
ios6::foundation::(anonymous namespace)::a_first(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_get_objects_range(ios6::objc::objc_object*, char const*, ios6::objc::objc_object**, ios6::foundation::NSRange)
ios6::foundation::(anonymous namespace)::a_hash(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_index_of(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_index_of_identical(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_init(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_init_array(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_init_capacity(ios6::objc::objc_object*, char const*, unsigned int)
ios6::foundation::(anonymous namespace)::a_init_objects(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*, ...)
ios6::foundation::(anonymous namespace)::a_init_objects_count(ios6::objc::objc_object*, char const*, ios6::objc::objc_object* const*, unsigned int)
ios6::foundation::(anonymous namespace)::a_is_equal_to_array(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_joined(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_last(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_make_perform(ios6::objc::objc_object*, char const*, char const*)
ios6::foundation::(anonymous namespace)::a_make_perform_with(ios6::objc::objc_object*, char const*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_mutable_copy(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_object_at(ios6::objc::objc_object*, char const*, unsigned int)
ios6::foundation::(anonymous namespace)::a_object_enumerator(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_reverse_enumerator(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::a_sorted_block(ios6::objc::objc_object*, char const*, ios6::Block*)
ios6::foundation::(anonymous namespace)::a_sorted_function(ios6::objc::objc_object*, char const*, unsigned int, unsigned int)
ios6::foundation::(anonymous namespace)::a_sorted_selector(ios6::objc::objc_object*, char const*, char const*)
ios6::foundation::(anonymous namespace)::a_subarray(ios6::objc::objc_object*, char const*, ios6::foundation::NSRange)
ios6::foundation::(anonymous namespace)::a_value_for_key(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_with_array(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_with_capacity(ios6::objc::objc_object*, char const*, unsigned int)
ios6::foundation::(anonymous namespace)::a_with_contents_of_file(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_with_contents_of_url(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_with_object(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::a_with_objects(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*, ...)
ios6::foundation::(anonymous namespace)::a_with_objects_count(ios6::objc::objc_object*, char const*, ios6::objc::objc_object* const*, unsigned int)
ios6::foundation::(anonymous namespace)::a_write_to_file(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*, bool)
ios6::foundation::(anonymous namespace)::add_object(ios6::foundation::(anonymous namespace)::Archiver&, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::add_observation(ios6::objc::objc_object*, ios6::foundation::(anonymous namespace)::Observation)
ios6::foundation::(anonymous namespace)::appending_component(std::__ndk1::basic_string<char, std::__ndk1::char_traits<char>, std::__ndk1::allocator<char> > const&, std::__ndk1::basic_string<char, std::__ndk1::char_traits<char>, std::__ndk1::allocator<char> > const&)
ios6::foundation::(anonymous namespace)::ar_archive_to_file(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_archived_data(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_dealloc(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::ar_encode_bool(ios6::objc::objc_object*, char const*, unsigned int, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_encode_bytes(ios6::objc::objc_object*, char const*, unsigned char const*, unsigned int, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_encode_double(ios6::objc::objc_object*, char const*, double, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_encode_float(ios6::objc::objc_object*, char const*, float, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_encode_int(ios6::objc::objc_object*, char const*, int, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_encode_int64(ios6::objc::objc_object*, char const*, long long, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_encode_object(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_encoded_data(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::ar_finish(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::ar_init(ios6::objc::objc_object*, char const*)
ios6::foundation::(anonymous namespace)::ar_init_data(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::ar_set_output_format(ios6::objc::objc_object*, char const*, unsigned int)
ios6::foundation::(anonymous namespace)::archive(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::archive_bytes(ios6::objc::objc_object*)
ios6::foundation::(anonymous namespace)::b_bundle_path(ios6::objc::objc_object*, char const*)
… +1127 more
```

## ios6::uikit… (763 symbols)
```
ios6::uikit::(anonymous namespace)::AS()::fallback
ios6::uikit::(anonymous namespace)::AppState::~AppState()
ios6::uikit::(anonymous namespace)::GState::~GState()
ios6::uikit::(anonymous namespace)::TextLine::~TextLine()
ios6::uikit::(anonymous namespace)::ac_timestamp(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::ac_x(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::ac_y(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::ac_z(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::acc_delegate(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::acc_interval(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::acc_set_delegate(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::acc_set_interval(ios6::objc::objc_object*, char const*, double)
ios6::uikit::(anonymous namespace)::acc_shared(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::ai_init_style(ios6::objc::objc_object*, char const*, int)
ios6::uikit::(anonymous namespace)::app_background_time_remaining(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_badge(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_begin_background_task(ios6::objc::objc_object*, char const*, ios6::Block*)
ios6::uikit::(anonymous namespace)::app_begin_ignoring(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_delegate(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_empty_array(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_end_ignoring(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_idle_timer_disabled(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_ignoring(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_init(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_key_window(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_no1(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::app_noop(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_noop1(ios6::objc::objc_object*, char const*, unsigned int)
ios6::uikit::(anonymous namespace)::app_set_badge(ios6::objc::objc_object*, char const*, int)
ios6::uikit::(anonymous namespace)::app_set_delegate(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::app_set_idle_timer_disabled(ios6::objc::objc_object*, char const*, unsigned int)
ios6::uikit::(anonymous namespace)::app_set_status_bar_hidden(ios6::objc::objc_object*, char const*, unsigned int)
ios6::uikit::(anonymous namespace)::app_set_status_bar_hidden_anim(ios6::objc::objc_object*, char const*, unsigned int, unsigned int)
ios6::uikit::(anonymous namespace)::app_set_status_bar_orientation(ios6::objc::objc_object*, char const*, int)
ios6::uikit::(anonymous namespace)::app_set_status_bar_orientation_anim(ios6::objc::objc_object*, char const*, int, unsigned int)
ios6::uikit::(anonymous namespace)::app_shared(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_state(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_status_bar_frame(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_status_bar_hidden(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_status_bar_orientation(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::app_windows(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::autoresize_subviews(ios6::objc::objc_object*, ios6::CGSize)
ios6::uikit::(anonymous namespace)::blend_pixel(ios6::uikit::(anonymous namespace)::ContextData*, unsigned int, unsigned int, float const*, float)
ios6::uikit::(anonymous namespace)::bundle_load_nib(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CFReleaseOrNull(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CFRetainOrNull(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformConcat(ios6::CGAffineTransform, ios6::CGAffineTransform)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformEqualToTransform(ios6::CGAffineTransform, ios6::CGAffineTransform)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformInvert(ios6::CGAffineTransform)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformIsIdentity(ios6::CGAffineTransform)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformMake(float, float, float, float, float, float)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformMakeRotation(float)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformMakeScale(float, float)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformMakeTranslation(float, float)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformRotate(ios6::CGAffineTransform, float)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformScale(ios6::CGAffineTransform, float, float)
ios6::uikit::(anonymous namespace)::c_CGAffineTransformTranslate(ios6::CGAffineTransform, float, float)
ios6::uikit::(anonymous namespace)::c_CGBitmapContextCreate(void*, unsigned int, unsigned int, unsigned int, unsigned int, ios6::objc::objc_object*, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGBitmapContextCreateImage(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGBitmapContextGetBitmapInfo(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGBitmapContextGetBitsPerComponent(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGBitmapContextGetBytesPerRow(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGBitmapContextGetData(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGBitmapContextGetHeight(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGBitmapContextGetWidth(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGColorCreate(ios6::objc::objc_object*, float const*)
ios6::uikit::(anonymous namespace)::c_CGColorCreateCopy(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGColorCreateCopyWithAlpha(ios6::objc::objc_object*, float)
ios6::uikit::(anonymous namespace)::c_CGColorEqualToColor(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGColorGetAlpha(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGColorGetColorSpace(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGColorGetComponents(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGColorGetNumberOfComponents(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGColorSpaceCreateDeviceGray()
ios6::uikit::(anonymous namespace)::c_CGColorSpaceCreateDeviceRGB()
ios6::uikit::(anonymous namespace)::c_CGColorSpaceGetModel(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGColorSpaceGetNumberOfComponents(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextClearRect(ios6::objc::objc_object*, ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGContextClipToMask(ios6::objc::objc_object*, ios6::CGRect, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextClipToRect(ios6::objc::objc_object*, ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGContextConcatCTM(ios6::objc::objc_object*, ios6::CGAffineTransform)
ios6::uikit::(anonymous namespace)::c_CGContextDrawImage(ios6::objc::objc_object*, ios6::CGRect, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextDrawLinearGradient(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::CGPoint, ios6::CGPoint, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGContextDrawRadialGradient(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::CGPoint, float, ios6::CGPoint, float, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGContextFillRect(ios6::objc::objc_object*, ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGContextGetCTM(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextIgnore(ios6::objc::objc_object*, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGContextRestoreGState(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextRotateCTM(ios6::objc::objc_object*, float)
ios6::uikit::(anonymous namespace)::c_CGContextSaveGState(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextScaleCTM(ios6::objc::objc_object*, float, float)
ios6::uikit::(anonymous namespace)::c_CGContextSetAlpha(ios6::objc::objc_object*, float)
ios6::uikit::(anonymous namespace)::c_CGContextSetFillColor(ios6::objc::objc_object*, float const*)
ios6::uikit::(anonymous namespace)::c_CGContextSetFillColorWithColor(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextSetFont(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextSetFontSize(ios6::objc::objc_object*, float)
ios6::uikit::(anonymous namespace)::c_CGContextSetGrayFillColor(ios6::objc::objc_object*, float, float)
ios6::uikit::(anonymous namespace)::c_CGContextSetLineWidth(ios6::objc::objc_object*, float)
ios6::uikit::(anonymous namespace)::c_CGContextSetRGBFillColor(ios6::objc::objc_object*, float, float, float, float)
ios6::uikit::(anonymous namespace)::c_CGContextSetRGBStrokeColor(ios6::objc::objc_object*, float, float, float, float)
ios6::uikit::(anonymous namespace)::c_CGContextSetShadow(ios6::objc::objc_object*, ios6::CGSize, float)
ios6::uikit::(anonymous namespace)::c_CGContextSetShadowWithColor(ios6::objc::objc_object*, ios6::CGSize, float, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextSetStrokeColor(ios6::objc::objc_object*, float const*)
ios6::uikit::(anonymous namespace)::c_CGContextSetStrokeColorWithColor(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGContextSetTextDrawingMode(ios6::objc::objc_object*, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGContextSetTextMatrix(ios6::objc::objc_object*, ios6::CGAffineTransform)
ios6::uikit::(anonymous namespace)::c_CGContextShowGlyphsAtPoint(ios6::objc::objc_object*, float, float, unsigned short const*, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGContextTranslateCTM(ios6::objc::objc_object*, float, float)
ios6::uikit::(anonymous namespace)::c_CGDataProviderCopyData(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGDataProviderCreateWithCFData(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGDataProviderCreateWithData(void*, void const*, unsigned int, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGDataProviderCreateWithFilename(char const*)
ios6::uikit::(anonymous namespace)::c_CGDataProviderCreateWithURL(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGFontCopyFullName(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGFontCopyTableForTag(ios6::objc::objc_object*, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGFontCreateWithDataProvider(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGFontCreateWithFontName(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGFontGetAscent(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGFontGetCapHeight(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGFontGetDescent(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGFontGetGlyphAdvances(ios6::objc::objc_object*, unsigned short const*, unsigned int, int*)
ios6::uikit::(anonymous namespace)::c_CGFontGetUnitsPerEm(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGFontGetXHeight(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGGradientCreateWithColorComponents(ios6::objc::objc_object*, float const*, float const*, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGGradientCreateWithColors(ios6::objc::objc_object*, ios6::objc::objc_object*, float const*)
ios6::uikit::(anonymous namespace)::c_CGImageCreate(unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, ios6::objc::objc_object*, unsigned int, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGImageCreateWithEncodedDataProvider(ios6::objc::objc_object*, float const*, unsigned int, unsigned int)
ios6::uikit::(anonymous namespace)::c_CGImageCreateWithImageInRect(ios6::objc::objc_object*, ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGImageCreateWithMask(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGImageGetAlphaInfo(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGImageGetBitsPerComponent(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGImageGetBitsPerPixel(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGImageGetBytesPerRow(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGImageGetColorSpace(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGImageGetDataProvider(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGImageGetHeight(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGImageGetWidth(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGPointApplyAffineTransform(ios6::CGPoint, ios6::CGAffineTransform)
ios6::uikit::(anonymous namespace)::c_CGPointEqualToPoint(ios6::CGPoint, ios6::CGPoint)
ios6::uikit::(anonymous namespace)::c_CGPointFromString(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGRectApplyAffineTransform(ios6::CGRect, ios6::CGAffineTransform)
ios6::uikit::(anonymous namespace)::c_CGRectContainsPoint(ios6::CGRect, ios6::CGPoint)
ios6::uikit::(anonymous namespace)::c_CGRectContainsRect(ios6::CGRect, ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectEqualToRect(ios6::CGRect, ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectFromString(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CGRectGetHeight(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectGetMaxX(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectGetMaxY(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectGetMidX(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectGetMidY(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectGetMinX(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectGetMinY(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectGetWidth(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectInset(ios6::CGRect, float, float)
ios6::uikit::(anonymous namespace)::c_CGRectIntegral(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectIntersection(ios6::CGRect, ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectIntersectsRect(ios6::CGRect, ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectIsEmpty(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectIsInfinite(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectIsNull(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectOffset(ios6::CGRect, float, float)
ios6::uikit::(anonymous namespace)::c_CGRectStandardize(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGRectUnion(ios6::CGRect, ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_CGSizeApplyAffineTransform(ios6::CGSize, ios6::CGAffineTransform)
ios6::uikit::(anonymous namespace)::c_CGSizeEqualToSize(ios6::CGSize, ios6::CGSize)
ios6::uikit::(anonymous namespace)::c_CGSizeFromString(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_CTFontManagerRegisterGraphicsFont(ios6::objc::objc_object*, ios6::objc::objc_object**)
ios6::uikit::(anonymous namespace)::c_NSStringFromCGPoint(ios6::CGPoint)
ios6::uikit::(anonymous namespace)::c_NSStringFromCGRect(ios6::CGRect)
ios6::uikit::(anonymous namespace)::c_NSStringFromCGSize(ios6::CGSize)
ios6::uikit::(anonymous namespace)::c_UIApplicationMain(int, char**, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_UIGraphicsBeginImageContext(ios6::CGSize)
ios6::uikit::(anonymous namespace)::c_UIGraphicsBeginImageContextWithOptions(ios6::CGSize, unsigned int, float)
ios6::uikit::(anonymous namespace)::c_UIGraphicsEndImageContext()
ios6::uikit::(anonymous namespace)::c_UIGraphicsGetCurrentContext()
ios6::uikit::(anonymous namespace)::c_UIGraphicsGetImageFromCurrentImageContext()
ios6::uikit::(anonymous namespace)::c_UIGraphicsPopContext()
ios6::uikit::(anonymous namespace)::c_UIGraphicsPushContext(ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::c_UIRectFill(ios6::CGRect)
ios6::uikit::(anonymous namespace)::col_cgcolor(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::col_description(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::col_get_rgba(ios6::objc::objc_object*, char const*, float*, float*, float*, float*)
ios6::uikit::(anonymous namespace)::col_get_white(ios6::objc::objc_object*, char const*, float*, float*)
ios6::uikit::(anonymous namespace)::col_init_coder(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::col_init_rgba(ios6::objc::objc_object*, char const*, float, float, float, float)
ios6::uikit::(anonymous namespace)::col_init_white(ios6::objc::objc_object*, char const*, float, float)
ios6::uikit::(anonymous namespace)::col_is_equal(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::col_pattern(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::col_rgba(ios6::objc::objc_object*, char const*, float, float, float, float)
ios6::uikit::(anonymous namespace)::col_set(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::col_white(ios6::objc::objc_object*, char const*, float, float)
ios6::uikit::(anonymous namespace)::col_with_alpha(ios6::objc::objc_object*, char const*, float)
ios6::uikit::(anonymous namespace)::col_with_cgcolor(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::compile_shader(unsigned int)
ios6::uikit::(anonymous namespace)::compressed_tex_image(unsigned int, int, unsigned int, int, int, int, int, void const*)
ios6::uikit::(anonymous namespace)::connection_init_coder(ios6::objc::objc_object*, char const*, ios6::objc::objc_object*)
ios6::uikit::(anonymous namespace)::ctx_api(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::ctx_current(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::ctx_dealloc(ios6::objc::objc_object*, char const*)
ios6::uikit::(anonymous namespace)::ctx_init_api(ios6::objc::objc_object*, char const*, int)
… +561 more
```

## ios6::… (1245 symbols)
```
ios6::(anonymous namespace)::AudioComponentFindNext(unsigned int, void const*)
ios6::(anonymous namespace)::AudioComponentInstanceDispose(ios6::(anonymous namespace)::Unit*)
ios6::(anonymous namespace)::AudioComponentInstanceNew(unsigned int, ios6::(anonymous namespace)::Unit**)
ios6::(anonymous namespace)::AudioFileClose(ios6::(anonymous namespace)::File*)
ios6::(anonymous namespace)::AudioFileGetProperty(ios6::(anonymous namespace)::File*, unsigned int, unsigned int*, void*)
ios6::(anonymous namespace)::AudioFileGetProperty(ios6::(anonymous namespace)::File*, unsigned int, unsigned int*, void*)::$_3::operator()() const
ios6::(anonymous namespace)::AudioFileGetPropertyInfo(ios6::(anonymous namespace)::File*, unsigned int, unsigned int*, unsigned int*)
ios6::(anonymous namespace)::AudioFileOpenURL(ios6::objc::objc_object*, signed char, unsigned int, ios6::(anonymous namespace)::File**)
ios6::(anonymous namespace)::AudioFileOpenWithCallbacks(unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, ios6::(anonymous namespace)::File**)
ios6::(anonymous namespace)::AudioFileOpenWithCallbacks(unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, ios6::(anonymous namespace)::File**)::count
ios6::(anonymous namespace)::AudioFileReadBytes(ios6::(anonymous namespace)::File*, unsigned char, long long, unsigned int*, void*)
ios6::(anonymous namespace)::AudioFileReadPacketData(ios6::(anonymous namespace)::File*, unsigned char, unsigned int*, void*, long long, unsigned int*, void*)
ios6::(anonymous namespace)::AudioFileReadPackets(ios6::(anonymous namespace)::File*, unsigned char, unsigned int*, void*, long long, unsigned int*, void*)
ios6::(anonymous namespace)::AudioOutputUnitStart(ios6::(anonymous namespace)::Unit*)
ios6::(anonymous namespace)::AudioOutputUnitStop(ios6::(anonymous namespace)::Unit*)
ios6::(anonymous namespace)::AudioQueueAddPropertyListener(ios6::(anonymous namespace)::Queue*, unsigned int, unsigned int, unsigned int)
ios6::(anonymous namespace)::AudioQueueAllocateBuffer(ios6::(anonymous namespace)::Queue*, unsigned int, ios6::(anonymous namespace)::Buffer**)
ios6::(anonymous namespace)::AudioQueueAllocateBufferWithPacketDescriptions(ios6::(anonymous namespace)::Queue*, unsigned int, unsigned int, ios6::(anonymous namespace)::Buffer**)
ios6::(anonymous namespace)::AudioQueueCreateTimeline(ios6::(anonymous namespace)::Queue*, unsigned int*)
ios6::(anonymous namespace)::AudioQueueDeviceGetCurrentTime(ios6::(anonymous namespace)::Queue*, void*)
ios6::(anonymous namespace)::AudioQueueDispose(ios6::(anonymous namespace)::Queue*, unsigned char)
ios6::(anonymous namespace)::AudioQueueDisposeTimeline(ios6::(anonymous namespace)::Queue*, unsigned int)
ios6::(anonymous namespace)::AudioQueueEnqueueBuffer(ios6::(anonymous namespace)::Queue*, ios6::(anonymous namespace)::Buffer*, unsigned int, void*)
ios6::(anonymous namespace)::AudioQueueEnqueueBufferWithParameters(ios6::(anonymous namespace)::Queue*, ios6::(anonymous namespace)::Buffer*, unsigned int, void*, ...)
ios6::(anonymous namespace)::AudioQueueFlush(ios6::(anonymous namespace)::Queue*)
ios6::(anonymous namespace)::AudioQueueFreeBuffer(ios6::(anonymous namespace)::Queue*, ios6::(anonymous namespace)::Buffer*)
ios6::(anonymous namespace)::AudioQueueGetCurrentTime(ios6::(anonymous namespace)::Queue*, unsigned int, void*, unsigned char*)
ios6::(anonymous namespace)::AudioQueueGetParameter(ios6::(anonymous namespace)::Queue*, unsigned int, float*)
ios6::(anonymous namespace)::AudioQueueGetProperty(ios6::(anonymous namespace)::Queue*, unsigned int, void*, unsigned int*)
ios6::(anonymous namespace)::AudioQueueGetPropertySize(ios6::(anonymous namespace)::Queue*, unsigned int, unsigned int*)
ios6::(anonymous namespace)::AudioQueueNewOutput(ios6::(anonymous namespace)::ASBD const*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, ios6::(anonymous namespace)::Queue**)
ios6::(anonymous namespace)::AudioQueueNewOutput(ios6::(anonymous namespace)::ASBD const*, unsigned int, unsigned int, unsigned int, unsigned int, unsigned int, ios6::(anonymous namespace)::Queue**)::$_4::operator()() const
ios6::(anonymous namespace)::AudioQueuePause(ios6::(anonymous namespace)::Queue*)
ios6::(anonymous namespace)::AudioQueuePrime(ios6::(anonymous namespace)::Queue*, unsigned int, unsigned int*)
ios6::(anonymous namespace)::AudioQueueRemovePropertyListener(ios6::(anonymous namespace)::Queue*, unsigned int, unsigned int, unsigned int)
ios6::(anonymous namespace)::AudioQueueReset(ios6::(anonymous namespace)::Queue*)
ios6::(anonymous namespace)::AudioQueueSetParameter(ios6::(anonymous namespace)::Queue*, unsigned int, float)
ios6::(anonymous namespace)::AudioQueueSetProperty(ios6::(anonymous namespace)::Queue*, unsigned int, void const*, unsigned int)
ios6::(anonymous namespace)::AudioQueueStart(ios6::(anonymous namespace)::Queue*, void const*)
ios6::(anonymous namespace)::AudioQueueStop(ios6::(anonymous namespace)::Queue*, unsigned char)
ios6::(anonymous namespace)::AudioServicesPlaySystemSound(unsigned int)
ios6::(anonymous namespace)::AudioSessionAddPropertyListener(unsigned int, void*, void*)
ios6::(anonymous namespace)::AudioSessionGetProperty(unsigned int, unsigned int*, void*)
ios6::(anonymous namespace)::AudioSessionGetProperty(unsigned int, unsigned int*, void*)::route
ios6::(anonymous namespace)::AudioSessionGetPropertySize(unsigned int, unsigned int*)
ios6::(anonymous namespace)::AudioSessionInitialize(void*, void*, void*, void*)
ios6::(anonymous namespace)::AudioSessionRemovePropertyListenerWithUserData(unsigned int, void*, void*)
ios6::(anonymous namespace)::AudioSessionSetActive(unsigned char)
ios6::(anonymous namespace)::AudioSessionSetProperty(unsigned int, unsigned int, void const*)
ios6::(anonymous namespace)::AudioUnitAddPropertyListener(ios6::(anonymous namespace)::Unit*, unsigned int, unsigned int, unsigned int)
ios6::(anonymous namespace)::AudioUnitAddRenderNotify(ios6::(anonymous namespace)::Unit*, unsigned int, unsigned int)
ios6::(anonymous namespace)::AudioUnitGetParameter(ios6::(anonymous namespace)::Unit*, unsigned int, unsigned int, unsigned int, float*)
ios6::(anonymous namespace)::AudioUnitGetProperty(ios6::(anonymous namespace)::Unit*, unsigned int, unsigned int, unsigned int, void*, unsigned int*)
ios6::(anonymous namespace)::AudioUnitGetPropertyInfo(ios6::(anonymous namespace)::Unit*, unsigned int, unsigned int, unsigned int, unsigned int*, unsigned char*)
ios6::(anonymous namespace)::AudioUnitInitialize(ios6::(anonymous namespace)::Unit*)
ios6::(anonymous namespace)::AudioUnitRemoveRenderNotify(ios6::(anonymous namespace)::Unit*, unsigned int, unsigned int)
ios6::(anonymous namespace)::AudioUnitRender(ios6::(anonymous namespace)::Unit*, unsigned int*, void const*, unsigned int, unsigned int, void*)
ios6::(anonymous namespace)::AudioUnitSetParameter(ios6::(anonymous namespace)::Unit*, unsigned int, unsigned int, unsigned int, float, unsigned int)
ios6::(anonymous namespace)::AudioUnitSetProperty(ios6::(anonymous namespace)::Unit*, unsigned int, unsigned int, unsigned int, void const*, unsigned int)
ios6::(anonymous namespace)::AudioUnitUninitialize(ios6::(anonymous namespace)::Unit*)
ios6::(anonymous namespace)::CATransform3DConcat(ios6::(anonymous namespace)::Transform3D, ios6::(anonymous namespace)::Transform3D)
ios6::(anonymous namespace)::CATransform3DEqualToTransform(ios6::(anonymous namespace)::Transform3D, ios6::(anonymous namespace)::Transform3D)
ios6::(anonymous namespace)::CATransform3DIdentity
ios6::(anonymous namespace)::CATransform3DIsIdentity(ios6::(anonymous namespace)::Transform3D)
ios6::(anonymous namespace)::CATransform3DMakeRotation(float, float, float, float)
ios6::(anonymous namespace)::CATransform3DMakeScale(float, float, float)
ios6::(anonymous namespace)::CATransform3DMakeTranslation(float, float, float)
ios6::(anonymous namespace)::CATransform3DRotate(ios6::(anonymous namespace)::Transform3D, float, float, float, float)
ios6::(anonymous namespace)::CATransform3DScale(ios6::(anonymous namespace)::Transform3D, float, float, float)
ios6::(anonymous namespace)::CATransform3DTranslate(ios6::(anonymous namespace)::Transform3D, float, float, float)
ios6::(anonymous namespace)::CFArrayGetTypeID()
ios6::(anonymous namespace)::CFArrayGetValues(ios6::objc::objc_object*, int, int, unsigned int*)
ios6::(anonymous namespace)::CFBitVectorCreate(void*, unsigned char const*, int)
ios6::(anonymous namespace)::CFBitVectorCreateCopy(void*, ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFBitVectorCreateMutable(void*, int)
ios6::(anonymous namespace)::CFBitVectorCreateMutableCopy(void*, int, ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFBitVectorGetBitAtIndex(ios6::objc::objc_object*, int)
ios6::(anonymous namespace)::CFBitVectorGetCount(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFBitVectorSetBitAtIndex(ios6::objc::objc_object*, int, unsigned int)
ios6::(anonymous namespace)::CFBitVectorSetCount(ios6::objc::objc_object*, int)
ios6::(anonymous namespace)::CFBooleanGetTypeID()
ios6::(anonymous namespace)::CFBundleGetVersionNumber(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFDataCreateWithBytesNoCopy(void*, unsigned char const*, int, void*)
ios6::(anonymous namespace)::CFDataGetTypeID()
ios6::(anonymous namespace)::CFDateGetTypeID()
ios6::(anonymous namespace)::CFDictionaryGetTypeID()
ios6::(anonymous namespace)::CFGetTypeID(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFGetTypeID(ios6::objc::objc_object*)::$_0::operator()(char const*) const
ios6::(anonymous namespace)::CFHostCreateWithName(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFHostGetAddressing(ios6::objc::objc_object*, unsigned char*)
ios6::(anonymous namespace)::CFHostStartInfoResolution(ios6::objc::objc_object*, int, void*)
ios6::(anonymous namespace)::CFLocaleCopyPreferredLanguages()
ios6::(anonymous namespace)::CFLocaleGetSystem()
ios6::(anonymous namespace)::CFMakeCollectable(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFNullGetTypeID()
ios6::(anonymous namespace)::CFNumberGetTypeID()
ios6::(anonymous namespace)::CFPreferencesAppSynchronize(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFPreferencesCopyAppValue(ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFPreferencesCopyValue(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFPreferencesGetAppBooleanValue(ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned char*)
ios6::(anonymous namespace)::CFPreferencesGetAppIntegerValue(ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned char*)
ios6::(anonymous namespace)::CFPreferencesSetAppValue(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFPreferencesSetValue(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFPreferencesSynchronize(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFRunLoopCopyAllModes(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFRunLoopRunInMode(ios6::objc::objc_object*, unsigned int, unsigned int, unsigned char)
ios6::(anonymous namespace)::CFShow(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFStreamClose(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFStreamCreatePairWithSocket(ios6::objc::objc_object*, int, unsigned int*, unsigned int*)
ios6::(anonymous namespace)::CFStreamCreatePairWithSocketToCFHost(ios6::objc::objc_object*, ios6::objc::objc_object*, int, unsigned int*, unsigned int*)
ios6::(anonymous namespace)::CFStreamCreatePairWithSocketToHost(ios6::objc::objc_object*, ios6::objc::objc_object*, unsigned int, unsigned int*, unsigned int*)
ios6::(anonymous namespace)::CFStreamOpen(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFStreamQuietly(ios6::objc::objc_object*, ios6::objc::objc_object*, ios6::objc::objc_object*)
ios6::(anonymous namespace)::CFStreamSetClient(ios6::objc::objc_object*, unsigned int, void*, void*)
ios6::(anonymous namespace)::CFStreamTransfer(ios6::objc::objc_object*, unsigned char*, int)
ios6::(anonymous namespace)::CFStringAppendCharacters(ios6::objc::objc_object*, char16_t const*, int)
ios6::(anonymous namespace)::CFStringCreateWithBytesNoCopy(void*, unsigned char const*, int, unsigned int, unsigned char, void*)
ios6::(anonymous namespace)::CFStringCreateWithBytesNoCopy(void*, unsigned char const*, int, unsigned int, unsigned char, void*)::create
ios6::(anonymous namespace)::CFStringGetBytes(ios6::objc::objc_object*, int, int, unsigned int, unsigned char, unsigned char, unsigned char*, int, int*)
ios6::(anonymous namespace)::CFStringGetSystemEncoding()
ios6::(anonymous namespace)::CFStringGetTypeID()
ios6::(anonymous namespace)::CMTimeMakeWithSeconds(double, int)
ios6::(anonymous namespace)::CNCopyCurrentNetworkInfo(ios6::objc::objc_object*)
ios6::(anonymous namespace)::CNCopySupportedInterfaces()
ios6::(anonymous namespace)::DelayedPerform::~DelayedPerform()
ios6::(anonymous namespace)::ExtAudioFileDispose(unsigned int)
ios6::(anonymous namespace)::ExtAudioFileGetProperty(unsigned int, unsigned int, unsigned int*, void*)
ios6::(anonymous namespace)::ExtAudioFileGetPropertyInfo(unsigned int, unsigned int, unsigned int*, unsigned char*)
ios6::(anonymous namespace)::ExtAudioFileOpenURL(ios6::objc::objc_object*, unsigned int*)
ios6::(anonymous namespace)::ExtAudioFileRead(unsigned int, unsigned int*, unsigned int*)
ios6::(anonymous namespace)::ExtAudioFileSeek(unsigned int, unsigned int, unsigned int)
ios6::(anonymous namespace)::ExtAudioFileSetProperty(unsigned int, unsigned int, unsigned int, void const*)
ios6::(anonymous namespace)::ExtAudioFileTell(unsigned int, long long*)
ios6::(anonymous namespace)::File::~File()
ios6::(anonymous namespace)::Loader::bind_at(unsigned int, char const*, int, unsigned char, unsigned char, long long, ios6::(anonymous namespace)::BindKind)
ios6::(anonymous namespace)::Loader::bind_symbol(unsigned int, unsigned int, ios6::(anonymous namespace)::BindKind, long long)
ios6::(anonymous namespace)::Loader::bind_table(unsigned int, unsigned int, ios6::(anonymous namespace)::BindKind)
ios6::(anonymous namespace)::Loader::classic_dyld_func_lookup(char const*, void**)
ios6::(anonymous namespace)::Loader::classic_dyld_nothing()
ios6::(anonymous namespace)::Loader::find_entry()
ios6::(anonymous namespace)::Loader::from_framework(int, std::initializer_list<char const*>) const
ios6::(anonymous namespace)::Loader::is_optional_framework(int) const::kOptional
ios6::(anonymous namespace)::Loader::is_optional_function(char const*)
ios6::(anonymous namespace)::Loader::protect()
ios6::(anonymous namespace)::Loader::rebase_at(unsigned int, unsigned char)
ios6::(anonymous namespace)::Loader::scan_sections()
ios6::(anonymous namespace)::Loader::select_slice()::kPreference
ios6::(anonymous namespace)::Loader::trap_low_pc_reads()
ios6::(anonymous namespace)::Loader::~Loader()
ios6::(anonymous namespace)::NSGetUncaughtExceptionHandler()
ios6::(anonymous namespace)::NSSetUncaughtExceptionHandler(unsigned int)
ios6::(anonymous namespace)::NXGetArchInfoFromCpuType(int, int)
ios6::(anonymous namespace)::NXGetArchInfoFromCpuType(int, int)::arm
ios6::(anonymous namespace)::NXGetLocalArchInfo()
ios6::(anonymous namespace)::NXGetLocalArchInfo()::info
ios6::(anonymous namespace)::OBJC_IVAR_NSObject_isa
ios6::(anonymous namespace)::SecKeyEncrypt(ios6::objc::objc_object*, unsigned int, unsigned char const*, unsigned int, unsigned char*, unsigned int*)
ios6::(anonymous namespace)::SecKeyGetBlockSize(ios6::objc::objc_object*)
ios6::(anonymous namespace)::Source::~Source()
ios6::(anonymous namespace)::TicketLock::~TicketLock()
ios6::(anonymous namespace)::UIImageJPEGRepresentation(ios6::objc::objc_object*, unsigned int, unsigned int)
ios6::(anonymous namespace)::UIImagePNGRepresentation(ios6::objc::objc_object*)
ios6::(anonymous namespace)::_keymgr_get_and_lock_processwide_ptr(unsigned int)
ios6::(anonymous namespace)::_keymgr_get_and_lock_processwide_ptr_2(unsigned int, void**)
ios6::(anonymous namespace)::_keymgr_set_and_unlock_processwide_ptr(unsigned int, void*)
ios6::(anonymous namespace)::_keymgr_unlock_processwide_ptr(unsigned int)
ios6::(anonymous namespace)::adddf3(double, double)
ios6::(anonymous namespace)::addsf3(float, float)
ios6::(anonymous namespace)::alBuffer3f(unsigned int, int, float, float, float)
ios6::(anonymous namespace)::alBuffer3i(unsigned int, int, int, int, int)
ios6::(anonymous namespace)::alBufferData(unsigned int, int, void const*, int, int)
ios6::(anonymous namespace)::alBufferDataStatic(int, int, void const*, int, int)
ios6::(anonymous namespace)::alBufferf(unsigned int, int, float)
ios6::(anonymous namespace)::alBufferfv(unsigned int, int, float const*)
ios6::(anonymous namespace)::alBufferi(unsigned int, int, int)
ios6::(anonymous namespace)::alBufferiv(unsigned int, int, int const*)
ios6::(anonymous namespace)::alDeleteBuffers(int, unsigned int const*)
ios6::(anonymous namespace)::alDeleteSources(int, unsigned int const*)
ios6::(anonymous namespace)::alDisable(int)
ios6::(anonymous namespace)::alDistanceModel(int)
ios6::(anonymous namespace)::alDopplerFactor(float)
ios6::(anonymous namespace)::alDopplerVelocity(float)
ios6::(anonymous namespace)::alEnable(int)
ios6::(anonymous namespace)::alGenBuffers(int, unsigned int*)
ios6::(anonymous namespace)::alGenSources(int, unsigned int*)
ios6::(anonymous namespace)::alGetBoolean(int)
ios6::(anonymous namespace)::alGetBooleanv(int, unsigned char*)
ios6::(anonymous namespace)::alGetBuffer3f(unsigned int, int, float*, float*, float*)
ios6::(anonymous namespace)::alGetBuffer3i(unsigned int, int, int*, int*, int*)
ios6::(anonymous namespace)::alGetBufferf(unsigned int, int, float*)
ios6::(anonymous namespace)::alGetBufferfv(unsigned int, int, float*)
ios6::(anonymous namespace)::alGetBufferi(unsigned int, int, int*)
ios6::(anonymous namespace)::alGetBufferiv(unsigned int, int, int*)
ios6::(anonymous namespace)::alGetDouble(int)
ios6::(anonymous namespace)::alGetDoublev(int, double*)
ios6::(anonymous namespace)::alGetEnumValue(char const*)
ios6::(anonymous namespace)::alGetError()
ios6::(anonymous namespace)::alGetFloat(int)
ios6::(anonymous namespace)::alGetFloatv(int, float*)
ios6::(anonymous namespace)::alGetInteger(int)
… +1036 more
```

## other (22827 symbols)
```
         w __cxa_thread_atexit_impl
$a
$a.0
$a.1
$a.10
$a.11
$a.12
$a.13
$a.14
$a.15
$a.16
$a.17
$a.18
$a.19
$a.2
$a.20
$a.21
$a.23
$a.24
$a.25
$a.26
$a.27
$a.28
$a.3
$a.30
$a.31
$a.32
$a.33
$a.34
$a.35
$a.36
$a.37
$a.38
$a.4
$a.40
$a.42
$a.5
$a.6
$a.7
$a.8
$a.9
$d
$d.1
$d.10
$d.100
$d.1000
$d.1001
$d.1002
$d.1003
$d.1005
$d.1006
$d.1007
$d.1008
$d.1009
$d.101
$d.1010
$d.1011
$d.1012
$d.1013
$d.1015
$d.1016
$d.1017
$d.1018
$d.1019
$d.102
$d.1021
$d.1023
$d.1025
$d.1027
$d.1029
$d.103
$d.1031
$d.1033
$d.1035
$d.1037
$d.1039
$d.104
$d.1041
$d.1043
$d.1045
$d.1047
$d.1048
$d.1049
$d.105
$d.1050
$d.1051
$d.1052
$d.1053
$d.1054
$d.1055
$d.1056
$d.1057
$d.1058
$d.1059
$d.106
$d.1060
$d.1061
$d.1062
$d.1063
$d.1064
$d.1065
$d.1066
$d.1067
$d.1069
$d.107
$d.1071
$d.1073
$d.1075
$d.1077
$d.1079
$d.108
$d.1081
$d.1083
$d.1085
$d.1087
$d.1089
$d.109
$d.1091
$d.1093
$d.1095
$d.1097
$d.1099
$d.11
$d.110
$d.1101
$d.1103
$d.1105
$d.1107
$d.1109
$d.111
$d.1111
$d.1113
$d.1115
$d.1117
$d.1119
$d.112
$d.1121
$d.1123
$d.1125
$d.1127
$d.1129
$d.113
$d.1131
$d.1133
$d.1135
$d.1137
$d.1138
$d.1139
$d.114
$d.1141
$d.1143
$d.1144
$d.1145
$d.1147
$d.1149
$d.115
$d.1151
$d.1153
$d.1155
$d.1156
$d.1157
$d.1158
$d.1159
$d.116
$d.1160
$d.1161
$d.1162
$d.1163
$d.1164
$d.1165
$d.1166
$d.1167
$d.1169
$d.117
$d.1171
$d.1173
$d.1175
$d.1177
$d.1179
$d.118
$d.1181
$d.1183
$d.1184
$d.1185
$d.1187
$d.1189
$d.119
$d.1191
$d.1193
$d.1195
$d.1197
$d.1199
$d.12
$d.120
$d.1201
$d.1203
$d.1205
$d.1207
$d.1208
$d.1209
$d.121
$d.1211
$d.1213
$d.1215
$d.1217
$d.1219
$d.122
$d.1221
$d.1223
$d.1225
$d.1227
$d.1229
$d.123
$d.1231
$d.1233
$d.1235
$d.1237
$d.1238
$d.1239
$d.124
$d.1240
$d.1241
$d.1242
$d.1243
$d.1244
$d.1245
$d.1246
$d.1247
$d.1248
$d.1249
$d.125
$d.1250
$d.1251
$d.1252
$d.1253
$d.1254
$d.1255
$d.1257
$d.1259
$d.126
$d.1261
$d.1263
$d.1265
$d.1266
$d.1267
$d.1268
$d.1269
$d.127
$d.1270
$d.1271
$d.1273
$d.1275
$d.1277
$d.1279
$d.128
$d.1281
$d.1283
$d.1284
$d.1285
$d.1286
$d.1287
$d.1289
$d.129
$d.1291
$d.1293
$d.1295
$d.1297
$d.1299
$d.13
$d.130
$d.1301
$d.1303
$d.1305
$d.1307
$d.1309
$d.131
$d.1311
$d.1313
$d.1315
$d.1317
$d.1319
$d.132
$d.1321
$d.1323
$d.1325
$d.1327
$d.1329
$d.133
$d.1331
$d.1333
$d.1335
$d.1337
$d.1339
$d.134
$d.1341
$d.1343
$d.1345
$d.1347
$d.1349
$d.135
$d.1351
$d.1353
$d.1355
$d.1357
$d.1359
$d.136
$d.1361
$d.1363
$d.1365
$d.1367
$d.1369
$d.137
$d.1371
$d.1373
$d.1375
$d.1377
$d.1379
$d.138
$d.1381
$d.1383
$d.1385
$d.1387
$d.1389
$d.139
$d.1391
$d.1393
$d.1395
$d.1397
$d.1399
$d.14
$d.140
$d.1401
$d.1403
$d.1405
$d.1407
$d.1409
$d.141
$d.1411
$d.1413
$d.1415
$d.1417
$d.1419
$d.142
$d.1421
$d.1423
$d.1425
$d.1427
$d.1429
$d.143
$d.1431
$d.1433
$d.1435
$d.1437
$d.1439
$d.144
$d.1441
$d.1443
$d.1445
$d.1447
$d.1449
$d.145
$d.1451
$d.1453
$d.1455
$d.1457
$d.1459
$d.146
$d.1461
$d.1463
$d.1465
$d.1467
$d.1469
$d.147
$d.1471
$d.1473
$d.1475
$d.1477
$d.1479
$d.148
$d.1481
$d.1483
$d.1485
$d.1487
$d.1489
$d.149
$d.1491
$d.1493
$d.1495
$d.1497
$d.1499
$d.15
$d.150
$d.1501
$d.1503
$d.1505
$d.1507
$d.1509
$d.151
$d.1511
$d.1513
… +9573 more
```