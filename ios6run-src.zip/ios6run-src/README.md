# ios6run — reconstructed pseudo-source

**What this is:** a reconstructed source-level view of `libios6run.so` (armeabi-v7a),
the iOS compatibility runtime that ships inside Guille's `com.guille.ios6run.*` APKs.
It contains **reconstructed** C++ files under `src/` — written from static analysis,
not decompiled line-by-line and **not the original source**.

**What the runtime actually is:** a user-space dyld + hand-written Objective-C
runtime + UIKit/Foundation/OpenAL reimplementation for Android. The game ships as an
*unmodified* iOS Mach-O in `assets/app/<Game>.app`; the runtime loads it natively
(armeabi-v7a CPU running the armv6/armv7/armv7s code directly — no emulation).

## Provenance / method

Evidence base, all from the shipped `libios6run.so` (5.59 MB, **not stripped**,
built with NDK r25 + libc++):

- `nm` full symtab: 26,894 symbols → `evidence/runtime-symbols.txt`
  (C++ namespaces survived: `ios6::objc`, `ios6::foundation`, `ios6::uikit`,
  `ios6::(anonymous)::Loader`, `macho::`)
- `_GLOBAL__sub_I_*.cpp` symbols leak the original file names →
  `evidence/source-units.txt` (app_main, loader, objc, foundation, ns_*.cpp,
  uikit, gles, openal, audio_*.cpp, runloop, dispatch, threads, blocks, nib,
  plist, network, coregraphics, cxx, libsystem, libc_more, libstdcxx, libunwind,
  commoncrypto, cf_more, png, …)
- DWARF debug info present only for libc++/libcxxabi units (34 CUs)
- imports: libandroid, liblog, libz, libdl, libEGL, libGLESv3, libm, libc;
  dlopen at runtime: libaaudio.so, libjnigraphics.so, libmediandk.so, libGLESv1_CM/GLESv2/GLESv3
- sole dynamic export: `ANativeActivity_onCreate` (NativeActivity contract)
- behavioral ground truth: two games known to run on it (Flappy Bird 1.2, Touch & Go 1.1)

## File map (reconstructed unit ↔ evidence)

| reconstructed file | original unit(s) | key evidence |
|---|---|---|
| `src/app_main.cpp`  | app_main.cpp, main.cpp | `ANativeActivity_onCreate`, JNI strings `getIntent`/`getStringExtra`, `c_UIApplicationMain` |
| `src/loader.cpp`    | loader.cpp | `Loader::select_slice/rebase_at/bind_at/bind_symbol/bind_table/scan_sections/find_entry/protect/trap_low_pc_reads/from_framework/is_optional_framework/classic_dyld_func_lookup`, strings `armv6/armv7/armv7s`, `: too small to be Mach-O`, `fat file has no 32-bit ARM slice`, `NXGetArchInfoFromCpuType` reimpl |
| `src/objc_runtime.cpp` | objc.cpp | `ios6::objc::{lookup_for, absorb_missing, absorb_unrecognized, ns_alloc, dispose_instance, fatal}` |
| `src/uikit.cpp`     | uikit.cpp | `ios6::uikit::{install, deliver_touches, resolve_symbol, present_drawn, named_color<>, sc_main, dev_*, set_display_window, TouchPhase, TouchPoint}`, `c_UIApplicationMain`, `g_display_link` |
| `src/gles_shim.cpp` | gles.cpp | `resolve_gles_symbol`, `fbo_gl*OES` family, `present_drawn` (glMatrixMode/glVertexPointer/glEnableClientState traces) |
| `src/audio.cpp`     | openal.cpp, audio_file/player/queue/unit.cpp | dlopen `libaaudio.so`, `mp_play/mp_init_url/pl_set_rate/as_load/as_shared/it_init_asset` |
| `src/runloop.cpp`   | runloop.cpp, dispatch.cpp, threads.cpp | `perform_later`, `o_perform_on_main`, `q_add_operation`, ALooper imports |
| `stubs/api-surface.md` | whole .so | machine-generated: every `ios6::`/`macho::` symbol grouped by namespace |

`evidence/` holds the raw dumps. `ipa2apk.sh` wraps any IPA into a fresh APK using
the shell in `shell/flap-runtime-shell.apk`.

**Disclaimers:** reconstructed for interoperability/study. Function bodies are
faithful to observed *behavior and symbol structure*, not to the original code.
No original Apple/Guille code is reproduced.